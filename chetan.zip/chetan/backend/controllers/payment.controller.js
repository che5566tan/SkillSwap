const paymentService = require('../services/payment.service');
const { successResponse } = require('../utils/response'); // adjust if your response helper is elsewhere

const createOrder = async (req, res, next) => {
  try {
    const { bookingId } = req.body;
    const order = await paymentService.createPayPalOrder(bookingId, req.user.id);
    successResponse(res, { orderId: order.id });
  } catch (err) {
    next(err);
  }
};

const captureOrder = async (req, res, next) => {
  try {
    const { orderId, bookingId } = req.body;
    const result = await paymentService.capturePayPalOrder(orderId, bookingId, req.user.id);
    successResponse(res, result, 'Payment successful');
  } catch (err) {
    next(err);
  }
};

module.exports = { createOrder, captureOrder };