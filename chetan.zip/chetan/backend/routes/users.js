const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const Skill = require('../models/Skill');
const Review = require('../models/Review');
const { protect } = require('../middleware/auth');

router.get('/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password -email');
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    const skills = await Skill.find({ provider: req.params.id, isActive: true });
    const reviews = await Review.find({ reviewee: req.params.id, isPublic: true })
      .populate('reviewer', 'name avatar')
      .populate('skill', 'title')
      .sort('-createdAt')
      .limit(10);
    res.json({ success: true, user, skills, reviews });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});
router.put(
  '/profile/update',
  protect,
  [
    body('name').optional().trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2-50 characters'),
    body('bio').optional().isLength({ max: 500 }).withMessage('Bio cannot exceed 500 characters'),
    body('location').optional().trim(),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) return res.status(400).json({ success: false, message: errors.array()[0].msg });
      const { name, bio, location, avatar, role } = req.body;
      const updateData = {};
      if (name) updateData.name = name;
      if (bio !== undefined) updateData.bio = bio;
      if (location !== undefined) updateData.location = location;
      if (avatar !== undefined) updateData.avatar = avatar;
      if (role && ['learner', 'provider'].includes(role)) updateData.role = role;
      const user = await User.findByIdAndUpdate(req.user._id, updateData, { new: true, runValidators: true });
      res.json({ success: true, message: 'Profile updated successfully.', user });
    } catch (error) {
      res.status(500).json({ success: false, message: 'Server error.' });
    }
  }
);
module.exports = router;