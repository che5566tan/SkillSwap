const express = require('express');
const router = express.Router();
const { paypalClient } = require('../config/paypal');
const checkoutNodeJssdk = require('@paypal/checkout-server-sdk');
const Booking = require('../models/Booking');
const { protect } = require('../middleware/auth');

// Create PayPal order
router.post('/create-order', protect, async (req, res) => {
  try {
    const { bookingId } = req.body;
    const booking = await Booking.findById(bookingId).populate('skill');
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });
    if (booking.learner.toString() !== req.user._id.toString())
      return res.status(403).json({ success: false, message: 'Unauthorized' });

    const request = new checkoutNodeJssdk.orders.OrdersCreateRequest();
    request.headers['prefer'] = 'return=representation';
    request.body = {
      intent: 'CAPTURE',
      purchase_units: [{
        amount: {
          currency_code: 'USD',
          value: booking.totalPrice.toFixed(2)
        },
        reference_id: booking._id.toString()
      }],
      application_context: {
        return_url: `${process.env.CLIENT_URL}/payment-success`,
        cancel_url: `${process.env.CLIENT_URL}/payment-cancel`
      }
    };

    const client = paypalClient();
    const order = await client.execute(request);
    booking.paypalOrderId = order.result.id;
    await booking.save();

    res.json({ success: true, orderId: order.result.id });
  } catch (err) {
    console.error('PayPal create order error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// Capture order
router.post('/capture-order', protect, async (req, res) => {
  try {
    const { orderId } = req.body;
    const booking = await Booking.findOne({ paypalOrderId: orderId });
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });

    const request = new checkoutNodeJssdk.orders.OrdersCaptureRequest(orderId);
    const client = paypalClient();
    const capture = await client.execute(request);

    booking.paymentStatus = 'paid';
    booking.paypalCaptureId = capture.result.purchase_units[0].payments.captures[0].id;
    // booking.paidAt = new Date(); // add this field to Booking schema if needed
    await booking.save();

    res.json({ success: true, bookingId: booking._id });
  } catch (err) {
    console.error('PayPal capture error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});
module.exports = router;