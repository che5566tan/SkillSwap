const express = require('express');
const router = express.Router();
const { body, validationResult, query } = require('express-validator');
const Skill = require('../models/Skill');
const User = require('../models/User');
const Review = require('../models/Review');
const { protect } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');

// @route   GET /api/skills
// @desc    Get all skills with search and filters
// @access  Public
router.get('/', async (req, res) => {
  try {
    const {
      search,
      category,
      level,
      minPrice,
      maxPrice,
      isFree,
      deliveryMethod,
      sortBy,
      page = 1,
      limit = 12,
    } = req.query;

    let query = { isActive: true };

    if (search) {
      query.$text = { $search: search };
    }
    if (category) query.category = category;
    if (level) query.level = level;
    if (isFree === 'true') query.isFree = true;
    if (deliveryMethod) query.deliveryMethod = deliveryMethod;
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = Number(minPrice);
      if (maxPrice) query.price.$lte = Number(maxPrice);
    }

    let sortOptions = { createdAt: -1 };
    if (sortBy === 'rating') sortOptions = { 'rating.average': -1 };
    if (sortBy === 'price-low') sortOptions = { price: 1 };
    if (sortBy === 'price-high') sortOptions = { price: -1 };
    if (sortBy === 'bookings') sortOptions = { totalBookings: -1 };

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const skills = await Skill.find(query)
      .populate('provider', 'name avatar rating location')
      .sort(sortOptions)
      .skip(skip)
      .limit(limitNum);

    const total = await Skill.countDocuments(query);

    res.json({
      success: true,
      skills,
      pagination: {
        total,
        page: pageNum,
        pages: Math.ceil(total / limitNum),
        limit: limitNum,
      },
    });
  } catch (error) {
    console.error('Skills fetch error:', error);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   GET /api/skills/my-skills
// @desc    Get current user's skills
// @access  Private
router.get('/my-skills', protect, async (req, res) => {
  try {
    const skills = await Skill.find({ provider: req.user._id }).sort('-createdAt');
    res.json({ success: true, skills });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   GET /api/skills/:id
// @desc    Get single skill
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const skill = await Skill.findById(req.params.id).populate(
      'provider',
      'name avatar bio rating location joinedAt'
    );

    if (!skill) {
      return res.status(404).json({ success: false, message: 'Skill not found.' });
    }

    const reviews = await Review.find({
      skill: req.params.id,
      reviewType: 'learner_to_provider',
      isPublic: true,
    })
      .populate('reviewer', 'name avatar')
      .sort('-createdAt')
      .limit(10);

    res.json({ success: true, skill, reviews });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   POST /api/skills
// @desc    Create a new skill listing
// @access  Private (Provider only)
router.post(
  '/',
  protect,
  authorize('provider', 'admin'),
  [
    body('title')
      .trim()
      .isLength({ min: 3, max: 100 })
      .withMessage('Title must be 3-100 characters'),
    body('description')
      .isLength({ min: 20, max: 2000 })
      .withMessage('Description must be 20-2000 characters'),
    body('category').notEmpty().withMessage('Category is required'),
    body('level').notEmpty().withMessage('Level is required'),
    body('sessionDuration')
      .isNumeric()
      .withMessage('Session duration must be a number'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, message: errors.array()[0].msg });
      }

      const skillData = {
        ...req.body,
        provider: req.user._id,
      };

      const skill = await Skill.create(skillData);

      await User.findByIdAndUpdate(req.user._id, {
        $push: { skills: skill._id },
      });

      const populatedSkill = await Skill.findById(skill._id).populate(
        'provider',
        'name avatar rating'
      );

      res.status(201).json({
        success: true,
        message: 'Skill listing created successfully!',
        skill: populatedSkill,
      });
    } catch (error) {
      console.error('Create skill error:', error);
      res.status(500).json({ success: false, message: 'Server error.' });
    }
  }
);

// @route   PUT /api/skills/:id
// @desc    Update skill listing
// @access  Private (Owner only)
router.put('/:id', protect, async (req, res) => {
  try {
    const skill = await Skill.findById(req.params.id);

    if (!skill) {
      return res.status(404).json({ success: false, message: 'Skill not found.' });
    }

    if (skill.provider.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to edit this skill.' });
    }

    const updatedSkill = await Skill.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    }).populate('provider', 'name avatar rating');

    res.json({
      success: true,
      message: 'Skill updated successfully!',
      skill: updatedSkill,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   DELETE /api/skills/:id
// @desc    Delete skill listing
// @access  Private (Owner only)
router.delete('/:id', protect, async (req, res) => {
  try {
    const skill = await Skill.findById(req.params.id);

    if (!skill) {
      return res.status(404).json({ success: false, message: 'Skill not found.' });
    }

    if (skill.provider.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to delete this skill.' });
    }

    await Skill.findByIdAndDelete(req.params.id);
    await User.findByIdAndUpdate(req.user._id, {
      $pull: { skills: req.params.id },
    });

    res.json({ success: true, message: 'Skill deleted successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;