const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Skill = require('../models/Skill');
const Booking = require('../models/Booking');
const Review = require('../models/Review');
const { protect } = require('../middleware/auth');
const { authorize } = require('../middleware/roleCheck');

// All routes require admin
router.use(protect, authorize('admin'));

// ------------------------------------------------------------
// STATS
// ------------------------------------------------------------
router.get('/stats', async (req, res) => {
  try {
    const [totalUsers, totalSkills, totalBookings, totalReviews] = await Promise.all([
      User.countDocuments(),
      Skill.countDocuments(),
      Booking.countDocuments(),
      Review.countDocuments(),
    ]);
    const bookingStats = await Booking.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]);
    const userRoleStats = await User.aggregate([{ $group: { _id: '$role', count: { $sum: 1 } } }]);
    const categoryStats = await Skill.aggregate([{ $match: { isActive: true } }, { $group: { _id: '$category', count: { $sum: 1 } } }, { $sort: { count: -1 } }]);
    const recentUsers = await User.find().select('name email role createdAt isBanned').sort('-createdAt').limit(10);
    res.json({ success: true, stats: { totalUsers, totalSkills, totalBookings, totalReviews, bookingStats, userRoleStats, categoryStats, recentUsers } });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// ------------------------------------------------------------
// USERS
// ------------------------------------------------------------
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 20, search, role } = req.query;
    let query = {};
    if (search) query.$or = [{ name: new RegExp(search, 'i') }, { email: new RegExp(search, 'i') }];
    if (role) query.role = role;
    const users = await User.find(query).select('-password').sort('-createdAt').skip((page-1)*limit).limit(parseInt(limit));
    const total = await User.countDocuments(query);
    res.json({ success: true, users, total });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// Update user details (name, email, bio, location, isBanned, role)
router.put('/users/:id', async (req, res) => {
  try {
    const { name, email, bio, location, isBanned, role } = req.body;
    const updateFields = {};
    if (name) updateFields.name = name;
    if (email) updateFields.email = email;
    if (bio !== undefined) updateFields.bio = bio;
    if (location !== undefined) updateFields.location = location;
    if (isBanned !== undefined) updateFields.isBanned = isBanned;
    if (role && ['learner', 'provider', 'admin'].includes(role)) updateFields.role = role;

    const user = await User.findByIdAndUpdate(req.params.id, updateFields, { new: true, runValidators: true }).select('-password');
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    res.json({ success: true, message: 'User updated.', user });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// Ban/unban (toggle)
router.put('/users/:id/ban', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    if (user.role === 'admin') return res.status(400).json({ success: false, message: 'Cannot ban admin.' });
    user.isBanned = !user.isBanned;
    await user.save();
    res.json({ success: true, message: `User ${user.isBanned ? 'banned' : 'unbanned'}.`, user });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// Change role
router.put('/users/:id/role', async (req, res) => {
  try {
    const { role } = req.body;
    if (!['learner', 'provider', 'admin'].includes(role)) return res.status(400).json({ success: false, message: 'Invalid role.' });
    const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true }).select('-password');
    if (!user) return res.status(404).json({ success: false, message: 'User not found.' });
    res.json({ success: true, message: 'Role updated.', user });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// ------------------------------------------------------------
// SKILLS
// ------------------------------------------------------------
router.get('/skills', async (req, res) => {
  try {
    const { page = 1, limit = 20, search } = req.query;
    let query = {};
    if (search) query.$text = { $search: search };
    const skills = await Skill.find(query).populate('provider', 'name email').sort('-createdAt').skip((page-1)*limit).limit(parseInt(limit));
    const total = await Skill.countDocuments(query);
    res.json({ success: true, skills, total });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// Update any skill (full object)
router.put('/skills/:id', async (req, res) => {
  try {
    const skill = await Skill.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true }).populate('provider', 'name email');
    if (!skill) return res.status(404).json({ success: false, message: 'Skill not found.' });
    res.json({ success: true, skill });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// Delete skill
router.delete('/skills/:id', async (req, res) => {
  try {
    const skill = await Skill.findByIdAndDelete(req.params.id);
    if (!skill) return res.status(404).json({ success: false, message: 'Skill not found.' });
    res.json({ success: true, message: 'Skill deleted.' });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// ------------------------------------------------------------
// BOOKINGS
// ------------------------------------------------------------
router.get('/bookings', async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate('skill', 'title')
      .populate('learner', 'name email')
      .populate('provider', 'name email')
      .sort('-createdAt')
      .limit(50);
    res.json({ success: true, bookings });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// Update booking (status, sessionLink, notes, etc.)
router.put('/bookings/:id', async (req, res) => {
  try {
    const { status, sessionLink, notes, providerResponse } = req.body;
    const updateFields = {};
    if (status) updateFields.status = status;
    if (sessionLink !== undefined) updateFields.sessionLink = sessionLink;
    if (notes !== undefined) updateFields.notes = notes;
    if (providerResponse !== undefined) updateFields.providerResponse = providerResponse;

    const booking = await Booking.findByIdAndUpdate(req.params.id, updateFields, { new: true })
      .populate('skill', 'title')
      .populate('learner', 'name email')
      .populate('provider', 'name email');
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found.' });
    res.json({ success: true, booking });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// ------------------------------------------------------------
// REVIEWS
// ------------------------------------------------------------
router.get('/reviews', async (req, res) => {
  try {
    const reviews = await Review.find()
      .populate('reviewer', 'name email')
      .populate('reviewee', 'name email')
      .populate('skill', 'title')
      .sort('-createdAt')
      .limit(50);
    res.json({ success: true, reviews });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

// Delete review (and recalc ratings)
router.delete('/reviews/:id', async (req, res) => {
  try {
    const review = await Review.findByIdAndDelete(req.params.id);
    if (!review) return res.status(404).json({ success: false, message: 'Review not found.' });
    // Recalculate ratings after deletion
    await Review.calculateRatings(review.skill, review.reviewee);
    res.json({ success: true, message: 'Review deleted.' });
  } catch (err) { res.status(500).json({ success: false, message: 'Server error.' }); }
});

module.exports = router;

