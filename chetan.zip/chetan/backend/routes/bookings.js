const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Booking = require('../models/Booking');
const Skill = require('../models/Skill');
const { protect } = require('../middleware/auth');

// @route   GET /api/bookings/my-bookings
// @desc    Get all bookings for current user (as learner)
// @access  Private
router.get('/my-bookings', protect, async (req, res) => {
  try {
    const { status } = req.query;
    let query = { learner: req.user._id };
    if (status) query.status = status;

    const bookings = await Booking.find(query)
      .populate('skill', 'title category image sessionDuration price isFree')
      .populate('provider', 'name avatar rating')
      .sort('-createdAt');

    res.json({ success: true, bookings });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   GET /api/bookings/incoming
// @desc    Get incoming booking requests for provider
// @access  Private
router.get('/incoming', protect, async (req, res) => {
  try {
    const { status } = req.query;
    let query = { provider: req.user._id };
    if (status) query.status = status;

    const bookings = await Booking.find(query)
      .populate('skill', 'title category image sessionDuration price isFree')
      .populate('learner', 'name avatar rating bio')
      .sort('-createdAt');

    res.json({ success: true, bookings });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   GET /api/bookings/:id
// @desc    Get single booking
// @access  Private
router.get('/:id', protect, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('skill', 'title category image sessionDuration price isFree description')
      .populate('learner', 'name avatar email bio')
      .populate('provider', 'name avatar email bio');

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found.' });
    }

    if (
      booking.learner._id.toString() !== req.user._id.toString() &&
      booking.provider._id.toString() !== req.user._id.toString() &&
      req.user.role !== 'admin'
    ) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    res.json({ success: true, booking });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   POST /api/bookings
// @desc    Create a booking request
// @access  Private
router.post(
  '/',
  protect,
  [
    body('skillId').notEmpty().withMessage('Skill ID is required'),
    body('requestedDate').notEmpty().withMessage('Date is required'),
    body('requestedTime').notEmpty().withMessage('Time is required'),
    body('message')
      .optional()
      .isLength({ max: 500 })
      .withMessage('Message cannot exceed 500 characters'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, message: errors.array()[0].msg });
      }

      const { skillId, requestedDate, requestedTime, message } = req.body;

      const skill = await Skill.findById(skillId);
      if (!skill || !skill.isActive) {
        return res.status(404).json({ success: false, message: 'Skill not found or unavailable.' });
      }

      if (skill.provider.toString() === req.user._id.toString()) {
        return res.status(400).json({ success: false, message: 'You cannot book your own skill.' });
      }

      const existingBooking = await Booking.findOne({
        skill: skillId,
        learner: req.user._id,
        status: { $in: ['pending', 'accepted'] },
      });

      if (existingBooking) {
        return res.status(400).json({
          success: false,
          message: 'You already have an active booking for this skill.',
        });
      }

      const booking = await Booking.create({
        skill: skillId,
        learner: req.user._id,
        provider: skill.provider,
        requestedDate: new Date(requestedDate),
        requestedTime,
        duration: skill.sessionDuration,
        message: message || '',
        totalPrice: skill.isFree ? 0 : skill.price,
      });

      await Skill.findByIdAndUpdate(skillId, { $inc: { totalBookings: 1 } });

      const populatedBooking = await Booking.findById(booking._id)
        .populate('skill', 'title category sessionDuration price isFree')
        .populate('provider', 'name avatar')
        .populate('learner', 'name avatar');

      res.status(201).json({
        success: true,
        message: 'Booking request sent successfully!',
        booking: populatedBooking,
      });
    } catch (error) {
      console.error('Booking creation error:', error);
      res.status(500).json({ success: false, message: 'Server error.' });
    }
  }
);

// @route   PUT /api/bookings/:id/respond
// @desc    Accept or reject booking (provider)
// @access  Private
router.put('/:id/respond', protect, async (req, res) => {
  try {
    const { status, providerResponse, sessionLink } = req.body;

    if (!['accepted', 'rejected'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Status must be accepted or rejected.' });
    }

    const booking = await Booking.findById(req.params.id);
    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found.' });
    }

    if (booking.paymentStatus !== 'paid') {
      return res.status(400).json({ success: false, message: 'Payment not completed yet' });
    }

    if (booking.provider.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Only the provider can respond to bookings.' });
    }

    if (booking.status !== 'pending') {
      return res.status(400).json({ success: false, message: 'Booking has already been responded to.' });
    }

    booking.status = status;
    booking.providerResponse = providerResponse || '';
    if (sessionLink) booking.sessionLink = sessionLink;
    await booking.save();

    const updatedBooking = await Booking.findById(booking._id)
      .populate('skill', 'title category sessionDuration')
      .populate('learner', 'name avatar email')
      .populate('provider', 'name avatar');

    res.json({
      success: true,
      message: `Booking ${status} successfully.`,
      booking: updatedBooking,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   PUT /api/bookings/:id/complete
// @desc    Mark booking as completed
// @access  Private
router.put('/:id/complete', protect, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found.' });
    }

    if (booking.paymentStatus !== 'paid') {
      return res.status(400).json({ success: false, message: 'Payment not completed yet' });
    }

    if (
      booking.provider.toString() !== req.user._id.toString() &&
      booking.learner.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ success: false, message: 'Not authorized.' });
    }

    if (booking.status !== 'accepted') {
      return res.status(400).json({ success: false, message: 'Only accepted bookings can be completed.' });
    }

    booking.status = 'completed';
    booking.completedAt = new Date();
    await booking.save();

    res.json({ success: true, message: 'Booking marked as completed.', booking });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   PUT /api/bookings/:id/cancel
// @desc    Cancel booking
// @access  Private
router.put('/:id/cancel', protect, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found.' });
    }

    if (booking.learner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Only the learner can cancel this booking.' });
    }

    if (!['pending', 'accepted'].includes(booking.status)) {
      return res.status(400).json({ success: false, message: 'Cannot cancel this booking.' });
    }

    booking.status = 'cancelled';
    await booking.save();

    res.json({ success: true, message: 'Booking cancelled successfully.', booking });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;