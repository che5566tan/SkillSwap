const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Review = require('../models/Review');
const Booking = require('../models/Booking');
const { protect } = require('../middleware/auth');

// @route   GET /api/reviews/skill/:skillId
// @desc    Get reviews for a skill
// @access  Public
router.get('/skill/:skillId', async (req, res) => {
  try {
    const reviews = await Review.find({
      skill: req.params.skillId,
      reviewType: 'learner_to_provider',
      isPublic: true,
    })
      .populate('reviewer', 'name avatar')
      .sort('-createdAt');

    res.json({ success: true, reviews });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   GET /api/reviews/user/:userId
// @desc    Get reviews for a user
// @access  Public
router.get('/user/:userId', async (req, res) => {
  try {
    const reviews = await Review.find({
      reviewee: req.params.userId,
      isPublic: true,
    })
      .populate('reviewer', 'name avatar')
      .populate('skill', 'title')
      .sort('-createdAt');

    res.json({ success: true, reviews });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @route   POST /api/reviews
// @desc    Create a review
// @access  Private
router.post(
  '/',
  protect,
  [
    body('bookingId').notEmpty().withMessage('Booking ID is required'),
    body('rating')
      .isInt({ min: 1, max: 5 })
      .withMessage('Rating must be between 1 and 5'),
    body('comment')
      .isLength({ min: 10, max: 1000 })
      .withMessage('Comment must be 10-1000 characters'),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ success: false, message: errors.array()[0].msg });
      }

      const { bookingId, rating, comment } = req.body;

      const booking = await Booking.findById(bookingId);
      if (!booking) {
        return res.status(404).json({ success: false, message: 'Booking not found.' });
      }

      if (booking.status !== 'completed') {
        return res.status(400).json({ success: false, message: 'Can only review completed sessions.' });
      }

      const isLearner = booking.learner.toString() === req.user._id.toString();
      const isProvider = booking.provider.toString() === req.user._id.toString();

      if (!isLearner && !isProvider) {
        return res.status(403).json({ success: false, message: 'Not authorized to review this booking.' });
      }

      if (isLearner && booking.learnerReviewed) {
        return res.status(400).json({ success: false, message: 'You have already reviewed this session.' });
      }
      if (isProvider && booking.providerReviewed) {
        return res.status(400).json({ success: false, message: 'You have already reviewed this session.' });
      }

      const reviewType = isLearner ? 'learner_to_provider' : 'provider_to_learner';
      const reviewee = isLearner ? booking.provider : booking.learner;

      const review = await Review.create({
        booking: bookingId,
        skill: booking.skill,
        reviewer: req.user._id,
        reviewee,
        rating,
        comment,
        reviewType,
      });

      if (isLearner) {
        booking.learnerReviewed = true;
      } else {
        booking.providerReviewed = true;
      }
      await booking.save();

      const populatedReview = await Review.findById(review._id).populate('reviewer', 'name avatar');

      res.status(201).json({
        success: true,
        message: 'Review submitted successfully!',
        review: populatedReview,
      });
    } catch (error) {
      if (error.code === 11000) {
        return res.status(400).json({ success: false, message: 'You have already reviewed this booking.' });
      }
      console.error('Review error:', error);
      res.status(500).json({ success: false, message: 'Server error.' });
    }
  }
);

module.exports = router;