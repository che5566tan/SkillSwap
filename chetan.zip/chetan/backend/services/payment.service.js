const { paypalClient } = require('../config/paypal');
const checkoutNodeJssdk = require('@paypal/checkout-server-sdk');
const Payment = require('../models/Payment');
const Booking = require('../models/Booking');

const createPayPalOrder = async (bookingId, userId) => {
  const booking = await Booking.findById(bookingId).populate('skillId');
  if (!booking) throw new Error('Booking not found');
  if (booking.userId.toString() !== userId.toString()) throw new Error('Not authorized');
  if (booking.paymentStatus === 'paid') throw new Error('Payment already completed');

  const request = new checkoutNodeJssdk.orders.OrdersCreateRequest();
  request.headers['prefer'] = 'return=representation';
  request.body = {
    intent: 'CAPTURE',
    purchase_units: [{
      amount: {
        currency_code: 'USD',
        value: booking.totalPrice.toFixed(2),
      },
      description: `Booking for skill: ${booking.skillId?.title || 'skill'}`,
    }],
  };

  const client = paypalClient();
  const order = await client.execute(request);

  await Payment.create({
    bookingId: booking._id,
    userId,
    payPalOrderId: order.result.id,
    amount: booking.totalPrice,
    status: 'created',
  });

  return order.result;
};

const capturePayPalOrder = async (orderId, bookingId, userId) => {
  const booking = await Booking.findById(bookingId);
  if (!booking) throw new Error('Booking not found');
  const payment = await Payment.findOne({ bookingId, payPalOrderId: orderId });
  if (!payment) throw new Error('Payment record not found');
  if (booking.paymentStatus === 'paid') throw new Error('Already paid');

  const request = new checkoutNodeJssdk.orders.OrdersCaptureRequest(orderId);
  const client = paypalClient();
  const capture = await client.execute(request);

  payment.status = 'captured';
  payment.captureId = capture.result.purchase_units[0].payments.captures[0].id;
  await payment.save();

  booking.paymentStatus = 'paid';
  await booking.save();

  return { payment, booking };
};

module.exports = { createPayPalOrder, capturePayPalOrder };