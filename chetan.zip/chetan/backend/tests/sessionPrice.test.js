function calculateSessionPrice(isFree, skillPrice) {
  if (isFree) return 0;
  if (skillPrice < 0) return 0;
  return skillPrice;
}

function isPriceValid(price, isFree) {
  if (isFree) return true;
  if (typeof price !== 'number') return false;
  if (price < 0) return false;
  return true;
}

// Test Suite 1: Session Price Calculation
describe('Session Price Calculation', () => {

  // SP-01: Free skill should always cost zero regardless of price field
  test('SP-01: Should return 0 for a free skill even if price field has a value', () => {
    const result = calculateSessionPrice(true, 50);
    expect(result).toBe(0);
  });

  // SP-02: Paid skill should return the exact price set by provider
  test('SP-02: Should return correct price for a standard paid session', () => {
    const result = calculateSessionPrice(false, 35);
    expect(result).toBe(35);
  });

  // SP-03: Paid skill with zero price should return zero
  test('SP-03: Should return 0 for a paid skill where provider set price to zero', () => {
    const result = calculateSessionPrice(false, 0);
    expect(result).toBe(0);
  });

  // SP-04: Negative price should be treated as zero — protect against bad data
  test('SP-04: Should return 0 if price is somehow negative — data protection', () => {
    const result = calculateSessionPrice(false, -10);
    expect(result).toBe(0);
  });

});

// Test Suite 2: Price Validation
describe('Skill Price Validation', () => {

  // SP-05: Valid paid price should pass validation
  test('SP-05: Should accept a valid positive price for a paid skill', () => {
    const result = isPriceValid(25, false);
    expect(result).toBe(true);
  });

  // SP-06: Free skill should always pass validation regardless of price field
  test('SP-06: Should accept any price value when skill is marked as free', () => {
    const result = isPriceValid(999, true);
    expect(result).toBe(true);
  });

  // SP-07: Negative price for paid skill should fail validation
  test('SP-07: Should reject negative price for a paid skill', () => {
    const result = isPriceValid(-5, false);
    expect(result).toBe(false);
  });

  // SP-08: Non-numeric price should fail validation
  test('SP-08: Should reject non-numeric price value', () => {
    const result = isPriceValid('free', false);
    expect(result).toBe(false);
  });

});