function isSelfBooking(learnerId, providerId) {
  return learnerId.toString() === providerId.toString();
}

function hasDuplicateActiveBooking(existingBookings, learnerId, skillId) {
  return existingBookings.some(
    (booking) =>
      booking.learner.toString() === learnerId.toString() &&
      booking.skill.toString() === skillId.toString() &&
      ['pending', 'accepted'].includes(booking.status)
  );
}

function isSkillAvailableForBooking(skill) {
  if (!skill) return false;
  return skill.isActive === true;
}

// Test Suite 1: Self-Booking Prevention
describe('Self-Booking Prevention', () => {

  // BV-01: Provider attempts to book their own skill
  test('BV-01: Should detect self-booking when learner and provider IDs match', () => {
    const userId = 'user_abc123';
    const result = isSelfBooking(userId, userId);
    expect(result).toBe(true);
  });

  // BV-02: Different learner books a skill — should be allowed
  test('BV-02: Should allow booking when learner and provider are different users', () => {
    const learnerId = 'learner_xyz789';
    const providerId = 'provider_abc123';
    const result = isSelfBooking(learnerId, providerId);
    expect(result).toBe(false);
  });

});

// Test Suite 2: Duplicate Active Booking Detection
describe('Duplicate Active Booking Detection', () => {

  const learnerId = 'learner_001';
  const skillId = 'skill_001';

  // BV-03: Learner already has a pending booking for the same skill
  test('BV-03: Should detect duplicate when learner has a pending booking for same skill', () => {
    const existingBookings = [
      { learner: 'learner_001', skill: 'skill_001', status: 'pending' }
    ];
    const result = hasDuplicateActiveBooking(existingBookings, learnerId, skillId);
    expect(result).toBe(true);
  });

  // BV-04: Learner already has an accepted booking for the same skill
  test('BV-04: Should detect duplicate when learner has an accepted booking for same skill', () => {
    const existingBookings = [
      { learner: 'learner_001', skill: 'skill_001', status: 'accepted' }
    ];
    const result = hasDuplicateActiveBooking(existingBookings, learnerId, skillId);
    expect(result).toBe(true);
  });

  // BV-05: Learner's previous booking was rejected — new booking should be allowed
  test('BV-05: Should allow new booking when previous booking was rejected', () => {
    const existingBookings = [
      { learner: 'learner_001', skill: 'skill_001', status: 'rejected' }
    ];
    const result = hasDuplicateActiveBooking(existingBookings, learnerId, skillId);
    expect(result).toBe(false);
  });

  // BV-06: Learner's previous booking was completed — new booking should be allowed
  test('BV-06: Should allow new booking when previous booking was completed', () => {
    const existingBookings = [
      { learner: 'learner_001', skill: 'skill_001', status: 'completed' }
    ];
    const result = hasDuplicateActiveBooking(existingBookings, learnerId, skillId);
    expect(result).toBe(false);
  });

});

// Test Suite 3: Skill Availability Check
describe('Skill Availability for Booking', () => {

  // BV-07: Active skill should be bookable
  test('BV-07: Should confirm active skill is available for booking', () => {
    const skill = { _id: 'skill_001', title: 'Guitar Lessons', isActive: true };
    const result = isSkillAvailableForBooking(skill);
    expect(result).toBe(true);
  });

  // BV-08: Inactive skill should not be bookable
  test('BV-08: Should reject booking attempt for inactive skill', () => {
    const skill = { _id: 'skill_002', title: 'Old Skill', isActive: false };
    const result = isSkillAvailableForBooking(skill);
    expect(result).toBe(false);
  });

  // BV-09: Null skill (skill not found) should not be bookable
  test('BV-09: Should reject booking attempt when skill does not exist', () => {
    const result = isSkillAvailableForBooking(null);
    expect(result).toBe(false);
  });
});