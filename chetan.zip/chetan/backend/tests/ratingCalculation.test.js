function calculateAverageRating(ratings) {
  if (!ratings || ratings.length === 0) return 0;
  const sum = ratings.reduce((total, rating) => total + rating, 0);
  const average = sum / ratings.length;
  return Math.round(average * 10) / 10;
}

function isRatingValid(rating) {
  if (typeof rating !== 'number') return false;
  if (!Number.isInteger(rating)) return false;
  if (rating < 1 || rating > 5) return false;
  return true;
}

// Test Suite 1: Average Rating Calculation
describe('Average Rating Calculation', () => {

  // RC-01: Multiple ratings producing a decimal average
  test('RC-01: Should calculate correct average from multiple ratings', () => {
    const ratings = [5, 4, 3, 5, 4];
    const result = calculateAverageRating(ratings);
    // Sum: 5+4+3+5+4 = 21, Count: 5, Average: 4.2
    expect(result).toBe(4.2);
  });

  // RC-02: Empty ratings array should return 0 not crash
  test('RC-02: Should return 0 when no ratings exist rather than crashing', () => {
    const ratings = [];
    const result = calculateAverageRating(ratings);
    expect(result).toBe(0);
  });

  // RC-03: Single rating should return itself unchanged
  test('RC-03: Should return the rating itself when only one review exists', () => {
    const ratings = [5];
    const result = calculateAverageRating(ratings);
    expect(result).toBe(5);
  });

  // RC-04: Average that requires rounding to one decimal place
  test('RC-04: Should round average correctly to one decimal place', () => {
    const ratings = [4, 5];
    const result = calculateAverageRating(ratings);
    // Sum: 9, Count: 2, Average: 4.5
    expect(result).toBe(4.5);
  });

});

// Test Suite 2: Rating Submission Validation
describe('Rating Submission Validation', () => {

  // RC-05: Valid rating of 5 should pass
  test('RC-05: Should accept a valid rating of 5', () => {
    const result = isRatingValid(5);
    expect(result).toBe(true);
  });

  // RC-06: Valid rating of 1 should pass
  test('RC-06: Should accept a valid rating of 1', () => {
    const result = isRatingValid(1);
    expect(result).toBe(true);
  });

  // RC-07: Rating of 0 should fail — below minimum
  test('RC-07: Should reject a rating of 0 — below minimum of 1', () => {
    const result = isRatingValid(0);
    expect(result).toBe(false);
  });

  // RC-08: Rating of 6 should fail — above maximum
  test('RC-08: Should reject a rating of 6 — above maximum of 5', () => {
    const result = isRatingValid(6);
    expect(result).toBe(false);
  });

});