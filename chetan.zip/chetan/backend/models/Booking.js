const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema(
  {
    skill: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Skill',
      required: true,
    },
    learner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    provider: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    requestedDate: {
      type: Date,
      required: [true, 'Requested date is required'],
    },
    requestedTime: {
      type: String,
      required: [true, 'Requested time is required'],
    },
    duration: {
      type: Number,
      required: true,
    },
    message: {
      type: String,
      maxlength: [500, 'Message cannot exceed 500 characters'],
      default: '',
    },
    status: {
      type: String,
      enum: ['pending', 'accepted', 'rejected', 'completed', 'cancelled'],
      default: 'pending',
    },
    totalPrice: {
      type: Number,
      default: 0,
    },
    providerResponse: {
      type: String,
      maxlength: [300, 'Response cannot exceed 300 characters'],
      default: '',
    },
    completedAt: {
      type: Date,
    },
    learnerReviewed: {
      type: Boolean,
      default: false,
    },
    providerReviewed: {
      type: Boolean,
      default: false,
    },
    sessionLink: {
      type: String,
      default: '',
    },
    notes: {
      type: String,
      default: '',
    },
    paymentStatus: {
      type: String,
      enum: ['pending', 'paid', 'refunded', 'failed'],
      default: 'pending'
    },
    paypalOrderId: String,
    paypalCaptureId: String,
    refundId: String,
    },
  { timestamps: true }
);

bookingSchema.index({ learner: 1, status: 1 });
bookingSchema.index({ provider: 1, status: 1 });
bookingSchema.index({ skill: 1 });

module.exports = mongoose.model('Booking', bookingSchema);