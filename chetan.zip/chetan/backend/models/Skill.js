const mongoose = require('mongoose');

const availabilitySlotSchema = new mongoose.Schema({
  day: {
    type: String,
    enum: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    required: true,
  },
  startTime: { type: String, required: true },
  endTime: { type: String, required: true },
});

const skillSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Skill title is required'],
      trim: true,
      minlength: [3, 'Title must be at least 3 characters'],
      maxlength: [100, 'Title cannot exceed 100 characters'],
    },
    description: {
      type: String,
      required: [true, 'Description is required'],
      minlength: [20, 'Description must be at least 20 characters'],
      maxlength: [2000, 'Description cannot exceed 2000 characters'],
    },
    category: {
      type: String,
      required: [true, 'Category is required'],
      enum: [
        'Technology',
        'Music',
        'Language',
        'Cooking',
        'Design',
        'Business',
        'Fitness',
        'Arts & Crafts',
        'Academic',
        'Other',
      ],
    },
    level: {
      type: String,
      enum: ['Beginner', 'Intermediate', 'Advanced', 'All Levels'],
      required: true,
    },
    price: {
      type: Number,
      default: 0,
      min: [0, 'Price cannot be negative'],
    },
    isFree: {
      type: Boolean,
      default: false,
    },
    sessionDuration: {
      type: Number,
      required: true,
      min: [15, 'Session must be at least 15 minutes'],
      max: [480, 'Session cannot exceed 8 hours'],
    },
    provider: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    availability: [availabilitySlotSchema],
    tags: [{ type: String, trim: true }],
    image: {
      type: String,
      default: '',
    },
    rating: {
      average: { type: Number, default: 0 },
      count: { type: Number, default: 0 },
    },
    totalBookings: {
      type: Number,
      default: 0,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    location: {
      type: String,
      default: 'Online',
    },
    deliveryMethod: {
      type: String,
      enum: ['Online', 'In-Person', 'Both'],
      default: 'Online',
    },
  },
  { timestamps: true }
);

skillSchema.index({ title: 'text', description: 'text', tags: 'text' });
skillSchema.index({ category: 1, level: 1, isActive: 1 });

module.exports = mongoose.model('Skill', skillSchema);
