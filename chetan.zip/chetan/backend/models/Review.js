const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema(
  {
    booking: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      required: true,
    },
    skill: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Skill',
      required: true,
    },
    reviewer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    reviewee: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    rating: {
      type: Number,
      required: [true, 'Rating is required'],
      min: [1, 'Rating must be at least 1'],
      max: [5, 'Rating cannot exceed 5'],
    },
    comment: {
      type: String,
      required: [true, 'Review comment is required'],
      minlength: [10, 'Comment must be at least 10 characters'],
      maxlength: [1000, 'Comment cannot exceed 1000 characters'],
    },
    reviewType: {
      type: String,
      enum: ['learner_to_provider', 'provider_to_learner'],
      required: true,
    },
    isPublic: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true }
);

reviewSchema.index({ booking: 1, reviewer: 1 }, { unique: true });

reviewSchema.statics.calculateRatings = async function (skillId, providerId) {
  const Skill = mongoose.model('Skill');
  const User = mongoose.model('User');

  const skillStats = await this.aggregate([
    { $match: { skill: skillId, reviewType: 'learner_to_provider' } },
    {
      $group: {
        _id: '$skill',
        avgRating: { $avg: '$rating' },
        count: { $sum: 1 },
      },
    },
  ]);

  if (skillStats.length > 0) {
    await Skill.findByIdAndUpdate(skillId, {
      'rating.average': Math.round(skillStats[0].avgRating * 10) / 10,
      'rating.count': skillStats[0].count,
    });
  }

  const userStats = await this.aggregate([
    { $match: { reviewee: providerId, reviewType: 'learner_to_provider' } },
    {
      $group: {
        _id: '$reviewee',
        avgRating: { $avg: '$rating' },
        count: { $sum: 1 },
      },
    },
  ]);

  if (userStats.length > 0) {
    await User.findByIdAndUpdate(providerId, {
      'rating.average': Math.round(userStats[0].avgRating * 10) / 10,
      'rating.count': userStats[0].count,
    });
  }
};

reviewSchema.post('save', function () {
  this.constructor.calculateRatings(this.skill, this.reviewee);
});

module.exports = mongoose.model('Review', reviewSchema);
