import React from 'react';

const StarRating = ({ rating = 0, maxStars = 5, size = 16, interactive = false, onRatingChange, showValue = false, count = null }) => {
  const [hovered, setHovered] = React.useState(0);

  return (
    <div className="flex items-center gap-xs" style={{ fontSize: size }}>
      {Array.from({ length: maxStars }, (_, i) => {
        const star = i + 1;
        const filled = (interactive ? (hovered || rating) : rating) >= star;
        const halfFilled = !filled && rating >= star - 0.5;
        return (
          <span
            key={star}
            style={{ cursor: interactive ? 'pointer' : 'default', transition: 'transform 0.1s, color 0.1s', transform: interactive && hovered >= star ? 'scale(1.2)' : 'scale(1)', color: filled ? '#f59e0b' : halfFilled ? '#f59e0b' : '#475569' }}
            onClick={() => interactive && onRatingChange?.(star)}
            onMouseEnter={() => interactive && setHovered(star)}
            onMouseLeave={() => interactive && setHovered(0)}
          >★</span>
        );
      })}
      {showValue && <span style={{ marginLeft: 6, color: 'var(--text-secondary)' }}>{rating > 0 ? rating.toFixed(1) : '—'} {count !== null && `(${count})`}</span>}
    </div>
  );
};
export default StarRating;