import React from 'react';

const Loader = ({ fullScreen = false, text = 'Loading...' }) => {
  const styleTag = (
    <style>{`
      @media (max-width: 480px) {
        .loader-text { font-size: 0.85rem; }
      }
    `}</style>
  );

  if (fullScreen) {
    return (
      <>
        {styleTag}
        <div className="flex items-center justify-center" style={{ height: '100vh', background: 'var(--bg-primary)' }}>
          <div className="flex-col items-center gap-md animate-fade-in">
            <div className="spinner" />
            <h2 className="gradient-text">SkillSwap</h2>
            <p className="text-secondary loader-text">{text}</p>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      {styleTag}
      <div className="flex items-center gap-sm">
        <div className="spinner spinner-sm" />
        <span className="text-secondary loader-text">{text}</span>
      </div>
    </>
  );
};

export default Loader;

