import React from 'react';

const Footer = () => (
  <footer style={{ borderTop: '1px solid var(--border)', padding: 'var(--space-lg) 0', textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
    <div className="container">© {new Date().getFullYear()} SkillSwap. Built with React &amp; Node.js</div>
  </footer>
);
export default Footer;