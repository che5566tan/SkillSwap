import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      {/* Responsive overrides and mobile menu styles */}
      <style>{`
        .nav-links-desktop {
          display: flex;
          align-items: center;
          gap: var(--space-md);
        }
        .hamburger {
          display: none;
          background: none;
          border: none;
          color: var(--text-primary);
          font-size: 1.6rem;
          cursor: pointer;
          padding: 0;
          line-height: 1;
        }
        .mobile-menu {
          position: fixed;
          top: 72px;
          left: 0;
          right: 0;
          background: var(--bg-secondary);
          border-bottom: 1px solid var(--border);
          padding: var(--space-md);
          display: none;
          flex-direction: column;
          gap: var(--space-sm);
          z-index: 999;
          backdrop-filter: blur(10px);
        }
        .mobile-menu.open {
          display: flex;
        }
        .mobile-menu a, .mobile-menu button {
          width: 100%;
          text-align: left;
          background: none;
          border: none;
          color: var(--text-primary);
          font-size: var(--font-size-base);
          padding: var(--space-sm) var(--space-md);
          border-radius: var(--radius-md);
          font-family: var(--font-family);
          font-weight: 500;
        }
        .mobile-menu a:hover, .mobile-menu button:hover {
          background: var(--bg-tertiary);
        }
        @media (max-width: 768px) {
          .nav-links-desktop {
            display: none !important;
          }
          .hamburger {
            display: block;
          }
        }
      `}</style>

      <nav style={{ position: 'fixed', top: 0, left: 0, right: 0, background: 'rgba(15,23,42,0.9)', backdropFilter: 'blur(10px)', borderBottom: '1px solid var(--border)', zIndex: 1000, height: 72, display: 'flex', alignItems: 'center' }}>
        <div className="container flex justify-between items-center" style={{ width: '100%' }}>
          {/* Logo */}
          <Link to="/" className="flex items-center gap-sm">
            <span className="gradient-text" style={{ fontSize: '1.5rem', fontWeight: 800 }}>SkillSwap</span>
          </Link>

          {/* Desktop links */}
          <div className="nav-links-desktop">
            {user ? (
              <>
                <Link to="/skills" className="btn btn-ghost">Browse Skills</Link>
                <Link to="/dashboard" className="btn btn-ghost">Dashboard</Link>
                {(user.role === 'provider' || user.role === 'admin') && (
                  <Link to="/skills/create" className="btn btn-primary btn-sm">+ New Skill</Link>
                )}
                {user.role === 'admin' && (
                  <Link to="/admin" className="btn btn-secondary btn-sm">Admin</Link>
                )}
                <button onClick={() => { logout(); navigate('/'); }} className="btn btn-ghost">Logout</button>
                <Link to="/profile" className="avatar avatar-md">{user.name.charAt(0)}</Link>
              </>
            ) : (
              <>
                <Link to="/skills" className="btn btn-ghost">Browse Skills</Link>
                <Link to="/login" className="btn btn-ghost">Login</Link>
                <Link to="/register" className="btn btn-primary btn-sm">Sign Up</Link>
              </>
            )}
          </div>

          {/* Hamburger (visible only on mobile) */}
          <button className="hamburger" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? '✕' : '☰'}
          </button>
        </div>
      </nav>

      {/* Mobile dropdown menu */}
      <div className={`mobile-menu ${menuOpen ? 'open' : ''}`}>
        {user ? (
          <>
            <Link to="/skills" onClick={() => setMenuOpen(false)}>Browse Skills</Link>
            <Link to="/dashboard" onClick={() => setMenuOpen(false)}>Dashboard</Link>
            {(user.role === 'provider' || user.role === 'admin') && (
              <Link to="/skills/create" onClick={() => setMenuOpen(false)}>+ New Skill</Link>
            )}
            {user.role === 'admin' && (
              <Link to="/admin" onClick={() => setMenuOpen(false)}>Admin</Link>
            )}
            <button onClick={() => { logout(); navigate('/'); setMenuOpen(false); }}>Logout</button>
            <Link to="/profile" onClick={() => setMenuOpen(false)}>Profile</Link>
          </>
        ) : (
          <>
            <Link to="/skills" onClick={() => setMenuOpen(false)}>Browse Skills</Link>
            <Link to="/login" onClick={() => setMenuOpen(false)}>Login</Link>
            <Link to="/register" onClick={() => setMenuOpen(false)}>Sign Up</Link>
          </>
        )}
      </div>
    </>
  );
};

export default Navbar;