import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import api from '../../services/api';

const SkillSearchInput = () => {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const wrapperRef = useRef(null);

  // Fetch suggestions with debounce
  useEffect(() => {
    const delayDebounce = setTimeout(async () => {
      if (query.length >= 2) {
        try {
          const res = await api.get('/skills', { params: { search: query, limit: 5 } });
          setSuggestions(res.data.skills || []);
          setShowDropdown(true);
        } catch { setSuggestions([]); }
      } else {
        setSuggestions([]);
        setShowDropdown(false);
      }
    }, 300);
    return () => clearTimeout(delayDebounce);
  }, [query]);

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={wrapperRef} style={{ position: 'relative' }}>
      <div className="search-container">
        <span className="search-icon">🔍</span>
        <input
          type="text"
          className="search-input"
          placeholder="Search skills..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => query.length >= 2 && suggestions.length > 0 && setShowDropdown(true)}
        />
      </div>
      {showDropdown && suggestions.length > 0 && (
        <ul
          className="card"
          style={{
            position: 'absolute',
            top: '100%',
            left: 0,
            right: 0,
            zIndex: 100,
            marginTop: 4,
            padding: '8px 0',
            maxHeight: 240,
            overflowY: 'auto',
          }}
        >
          {suggestions.map((skill) => (
            <li key={skill._id}>
              <Link
                to={`/skills/${skill._id}`}
                onClick={() => setShowDropdown(false)}
                style={{
                  display: 'block',
                  padding: '8px 16px',
                  color: 'var(--text-primary)',
                }}
                onMouseEnter={(e) => (e.target.style.background = 'var(--bg-tertiary)')}
                onMouseLeave={(e) => (e.target.style.background = 'transparent')}
              >
                <div style={{ fontWeight: 600 }}>{skill.title}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                  {skill.category} · {skill.level}
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SkillSearchInput;
