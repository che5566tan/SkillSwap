import React from 'react';
import { Link } from 'react-router-dom';
import StarRating from '../common/StarRating';

const SkillCard = ({ skill }) => (
  <Link to={`/skills/${skill._id}`} className="card card-hover" style={{ display: 'flex', flexDirection: 'column', textDecoration: 'none' }}>
    <div style={{ flex: 1 }}>
      <div className="flex justify-between items-start">
        <span className="badge badge-primary">{skill.category}</span>
        <span className="badge badge-secondary">{skill.level}</span>
      </div>
      <h3 style={{ margin: '12px 0 4px', fontSize: '1.25rem' }}>{skill.title}</h3>
      <p className="text-secondary" style={{ fontSize: '0.875rem', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
        {skill.description}
      </p>
      <div className="tags-container" style={{ marginTop: 8 }}>
        {skill.tags?.slice(0, 3).map(tag => <span key={tag} className="tag">{tag}</span>)}
      </div>
    </div>
    <div className="flex justify-between items-center" style={{ marginTop: 16, borderTop: '1px solid var(--border)', paddingTop: 12 }}>
      <div className="flex items-center gap-sm">
        <div className="avatar avatar-sm">{skill.provider?.name?.charAt(0)}</div>
        <span className="text-secondary" style={{ fontSize: '0.8rem' }}>{skill.provider?.name}</span>
      </div>
      <div className="flex items-center gap-sm">
        <StarRating rating={skill.rating?.average || 0} size={14} />
        <span className="text-secondary" style={{ fontSize: '0.8rem' }}>({skill.rating?.count || 0})</span>
      </div>
    </div>
    <div className="flex justify-between items-center" style={{ marginTop: 8 }}>
      <strong className="gradient-text">{skill.isFree ? 'Free' : `$${skill.price}`}</strong>
      <span className="badge badge-neutral">{skill.sessionDuration} min</span>
    </div>
  </Link>
);

export default SkillCard;
