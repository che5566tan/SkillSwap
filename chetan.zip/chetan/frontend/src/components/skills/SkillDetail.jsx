import React from 'react';
import StarRating from '../common/StarRating';
import { Link } from 'react-router-dom';

const SkillDetail = ({ skill, reviews, onBook }) => (
  <div className="animate-fade-in">
    <div className="card" style={{ marginBottom: 32 }}>
      <div className="flex justify-between items-start">
        <div>
          <span className="badge badge-primary" style={{ marginRight: 8 }}>{skill.category}</span>
          <span className="badge badge-secondary">{skill.level}</span>
          <h1 style={{ margin: '12px 0' }}>{skill.title}</h1>
        </div>
        <div style={{ textAlign: 'right' }}>
          <span className="gradient-text" style={{ fontSize: '1.8rem', fontWeight: 700 }}>{skill.isFree ? 'Free' : `$${skill.price}`}</span>
          <p className="text-secondary">{skill.sessionDuration} mins per session</p>
        </div>
      </div>
      <p style={{ whiteSpace: 'pre-wrap', margin: '16px 0' }}>{skill.description}</p>
      <div className="tags-container" style={{ marginBottom: 16 }}>
        {skill.tags?.map(tag => <span key={tag} className="tag">{tag}</span>)}
      </div>
      <div className="flex items-center gap-md">
        <div className="flex items-center gap-sm">
          <div className="avatar avatar-md">{skill.provider?.name?.charAt(0)}</div>
          <div>
            <strong>{skill.provider?.name}</strong>
            <p className="text-secondary" style={{ fontSize: '0.8rem' }}>{skill.provider?.location}</p>
          </div>
        </div>
        <div className="flex items-center gap-sm" style={{ marginLeft: 'auto' }}>
          <StarRating rating={skill.rating?.average || 0} size={20} showValue count={skill.rating?.count} />
        </div>
      </div>
      <button onClick={onBook} className="btn btn-primary btn-lg" style={{ marginTop: 24 }}>Request Booking</button>
    </div>

    <h3>Availability</h3>
    <div className="card" style={{ marginBottom: 32 }}>
      {skill.availability?.length ? skill.availability.map(slot => (
        <div key={slot._id} className="flex justify-between" style={{ padding: '6px 0', borderBottom: '1px solid var(--border)' }}>
          <strong>{slot.day}</strong>
          <span>{slot.startTime} - {slot.endTime}</span>
        </div>
      )) : <p className="text-secondary">Flexible, contact to arrange.</p>}
    </div>

    <h3>Reviews ({reviews.length})</h3>
    {reviews.map(r => (
      <div key={r._id} className="card" style={{ marginBottom: 12 }}>
        <div className="flex justify-between">
          <div className="flex items-center gap-sm">
            <div className="avatar avatar-sm">{r.reviewer?.name?.charAt(0)}</div>
            <strong>{r.reviewer?.name}</strong>
          </div>
          <StarRating rating={r.rating} size={14} />
        </div>
        <p className="text-secondary" style={{ marginTop: 8 }}>{r.comment}</p>
      </div>
    ))}
  </div>
);

export default SkillDetail;