import React from 'react';

const categories = ['Technology', 'Music', 'Language', 'Cooking', 'Design', 'Business', 'Fitness', 'Arts & Crafts', 'Academic', 'Other'];
const levels = ['Beginner', 'Intermediate', 'Advanced', 'All Levels'];
const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const SkillForm = ({ formData, setFormData, onSubmit, loading, isEdit = false }) => {
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === 'checkbox') setFormData({ ...formData, [name]: checked });
    else setFormData({ ...formData, [name]: value });
  };

  const handleAvailability = (day, field, value) => {
    const avail = [...(formData.availability || [])];
    const existing = avail.find(a => a.day === day);
    if (existing) {
      existing[field] = value;
    } else {
      avail.push({ day, startTime: '09:00', endTime: '17:00', [field]: value });
    }
    setFormData({ ...formData, availability: avail });
  };

  const addTag = (e) => {
    if (e.key === 'Enter' && e.target.value) {
      e.preventDefault();
      setFormData({ ...formData, tags: [...(formData.tags || []), e.target.value], tagInput: '' });
    }
  };

  return (
    <form onSubmit={onSubmit} className="card" style={{ maxWidth: 700, margin: '0 auto' }}>
      <h2 className="gradient-text" style={{ marginBottom: 24 }}>{isEdit ? 'Edit Skill' : 'Create New Skill'}</h2>
      <div className="form-group">
        <label className="form-label">Title *</label>
        <input type="text" name="title" className="form-control" required value={formData.title} onChange={handleChange} />
      </div>
      <div className="form-group">
        <label className="form-label">Description *</label>
        <textarea name="description" className="form-control" required rows={4} value={formData.description} onChange={handleChange} />
      </div>
      <div className="grid grid-2 gap-md">
        <div className="form-group">
          <label className="form-label">Category *</label>
          <select name="category" className="form-control" required value={formData.category} onChange={handleChange}>
            <option value="">Select</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">Level *</label>
          <select name="level" className="form-control" required value={formData.level} onChange={handleChange}>
            <option value="">Select</option>
            {levels.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
      </div>
      <div className="grid grid-3 gap-md">
        <div className="form-group">
          <label className="form-label">Price ($)</label>
          <input type="number" name="price" className="form-control" min="0" step="0.01" value={formData.price} onChange={handleChange} />
        </div>
        <div className="form-group">
          <label className="form-label">Session Duration (min) *</label>
          <input type="number" name="sessionDuration" className="form-control" required min="15" max="480" value={formData.sessionDuration} onChange={handleChange} />
        </div>
        <div className="form-group" style={{ justifyContent: 'flex-end' }}>
          <label className="form-checkbox">
            <input type="checkbox" name="isFree" checked={formData.isFree || false} onChange={handleChange} />
            <span className="form-label" style={{ marginLeft: 8 }}>Free Session</span>
          </label>
        </div>
      </div>
      <div className="form-group">
        <label className="form-label">Delivery Method</label>
        <select name="deliveryMethod" className="form-control" value={formData.deliveryMethod || 'Online'} onChange={handleChange}>
          <option value="Online">Online</option>
          <option value="In-Person">In-Person</option>
          <option value="Both">Both</option>
        </select>
      </div>
      <div className="form-group">
        <label className="form-label">Tags</label>
        <div className="tags-container" style={{ marginBottom: 8 }}>
          {(formData.tags || []).map((tag, idx) => (
            <span key={idx} className="tag" style={{ cursor: 'pointer' }} onClick={() => setFormData({ ...formData, tags: formData.tags.filter((_, i) => i !== idx) })}>{tag} ✕</span>
          ))}
        </div>
        <input type="text" className="form-control" placeholder="Type tag and press Enter" value={formData.tagInput || ''} onChange={e => setFormData({ ...formData, tagInput: e.target.value })} onKeyDown={addTag} />
      </div>
      <fieldset style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: 'var(--space-md)', margin: 'var(--space-md) 0' }}>
        <legend className="form-label">Availability</legend>
        {days.map(day => (
          <div key={day} className="flex items-center gap-md" style={{ marginBottom: 8 }}>
            <span style={{ width: 100 }}>{day}</span>
            <input type="time" className="form-control" style={{ width: 120 }} value={formData.availability?.find(a => a.day === day)?.startTime || '09:00'} onChange={e => handleAvailability(day, 'startTime', e.target.value)} />
            <span>-</span>
            <input type="time" className="form-control" style={{ width: 120 }} value={formData.availability?.find(a => a.day === day)?.endTime || '17:00'} onChange={e => handleAvailability(day, 'endTime', e.target.value)} />
          </div>
        ))}
      </fieldset>
      <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%' }} disabled={loading}>
        {loading ? 'Saving...' : isEdit ? 'Update Skill' : 'Create Skill'}
      </button>
    </form>
  );
};

export default SkillForm;