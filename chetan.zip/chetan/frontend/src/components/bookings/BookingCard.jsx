import React from 'react';
import { format } from 'date-fns';

const statusColors = {
  pending: 'warning',
  pending_payment: 'neutral',
  paid_pending: 'info',
  accepted: 'success',
  rejected: 'error',
  completed: 'primary',
  cancelled: 'neutral',
};

const BookingCard = ({ booking, userId, onRespond, onComplete, onCancel, onReview }) => {
  const isProvider = booking.provider?._id === userId || booking.provider === userId;
  const isLearner = booking.learner?._id === userId || booking.learner === userId;

  // Determine if payment is required and has been made
  const needsPayment = booking.totalPrice > 0 && booking.paymentStatus !== 'paid';
  const isPaid = booking.paymentStatus === 'paid';

  return (
    <div className="card" style={{ marginBottom: 16 }}>
      <div className="flex justify-between items-start">
        <div>
          <h4>{booking.skill?.title}</h4>
          <p className="text-secondary" style={{ fontSize: '0.85rem' }}>
            {booking.skill?.category} · {booking.duration || booking.skill?.sessionDuration} min
          </p>
        </div>
        <span className={`badge badge-${statusColors[booking.status] || 'neutral'}`}>
          {booking.status === 'pending_payment' ? 'Awaiting Payment' : booking.status}
        </span>
      </div>

      <div className="grid grid-2" style={{ margin: '12px 0', fontSize: '0.9rem' }}>
        <div><strong>Date:</strong> {format(new Date(booking.requestedDate), 'PPP')}</div>
        <div><strong>Time:</strong> {booking.requestedTime}</div>
        <div><strong>Learner:</strong> {booking.learner?.name}</div>
        <div><strong>Provider:</strong> {booking.provider?.name}</div>
        {booking.totalPrice > 0 && <div><strong>Price:</strong> £{booking.totalPrice}</div>}
        {needsPayment && <div><strong>Payment:</strong> <span className="badge badge-warning">Required</span></div>}
        {isPaid && <div><strong>Payment:</strong> <span className="badge badge-success">Paid</span></div>}
      </div>

      {booking.message && (
        <p className="text-secondary" style={{ fontStyle: 'italic', marginTop: 8 }}>"{booking.message}"</p>
      )}

      <div className="flex gap-sm" style={{ marginTop: 12 }}>
        {/* Provider actions – only if paid */}
        {isProvider && booking.status === 'pending' && isPaid && (
          <>
            <button onClick={() => onRespond(booking._id, 'accepted')} className="btn btn-success btn-sm">Accept</button>
            <button onClick={() => onRespond(booking._id, 'rejected')} className="btn btn-danger btn-sm">Reject</button>
          </>
        )}

        {/* Shared complete/cancel for accepted bookings – only if paid */}
        {booking.status === 'accepted' && isPaid && (
          <>
            <button onClick={() => onComplete(booking._id)} className="btn btn-primary btn-sm">Mark Completed</button>
            {isLearner && (
              <button onClick={() => onCancel(booking._id)} className="btn btn-ghost btn-sm">Cancel</button>
            )}
          </>
        )}

        {/* Review button after completion */}
        {booking.status === 'completed' && (
          <>
            {isLearner && !booking.learnerReviewed && (
              <button onClick={() => onReview(booking._id)} className="btn btn-outline btn-sm">Leave Review</button>
            )}
            {isProvider && !booking.providerReviewed && (
              <button onClick={() => onReview(booking._id)} className="btn btn-outline btn-sm">Review Learner</button>
            )}
          </>
        )}

        {/* If not paid and learner, show message */}
        {isLearner && needsPayment && booking.status === 'pending_payment' && (
          <span className="text-secondary" style={{ fontSize: '0.8rem' }}>Complete payment to proceed</span>
        )}
      </div>
    </div>
  );
};

export default BookingCard;