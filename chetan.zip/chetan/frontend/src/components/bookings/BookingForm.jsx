import React, { useState } from 'react';
import { format } from 'date-fns';
import { PayPalButtons } from '@paypal/react-paypal-js';
import api from "../../services/api";
import toast from 'react-hot-toast';

const BookingForm = ({ skill, onClose, onSuccess }) => {
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [time, setTime] = useState('10:00');
  const [message, setMessage] = useState('');
  const [step, setStep] = useState('form'); // 'form' or 'payment'
  const [bookingId, setBookingId] = useState(null);
  const [loading, setLoading] = useState(false);

  // Step 1: Create booking (pending payment)
  const createBooking = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.post('/bookings', {
        skillId: skill._id,
        requestedDate: date,
        requestedTime: time,
        message,
      });
      setBookingId(res.data.booking._id);
      setStep('payment');
      toast.success('Booking created! Please complete payment.');
    } catch (err) {
      toast.error(err.displayMessage || 'Failed to create booking');
    } finally {
      setLoading(false);
    }
  };

  // Step 2: PayPal order creation
  const createOrder = async () => {
    try {
      const res = await api.post('/payments/create-order', { bookingId });
      return res.data.orderId;
    } catch (err) {
      toast.error('Could not initiate payment');
      throw err;
    }
  };

  // Step 3: After PayPal approval
  const onApprove = async (data) => {
    try {
      await api.post('/payments/capture-order', { orderId: data.orderID });
      toast.success('Payment successful! Your request has been sent to the provider.');
      onSuccess(); // close modal and refresh parent
    } catch (err) {
      toast.error('Payment capture failed');
    }
  };

  const onError = (err) => {
    console.error('PayPal error:', err);
    toast.error('Payment error. Please try again.');
  };

  if (step === 'payment') {
    return (
      <div className="modal-overlay" onClick={onClose}>
        <div className="modal" onClick={e => e.stopPropagation()}>
          <div className="card-header">
            <h3>Complete Payment for {skill.title}</h3>
            <button className="modal-close" onClick={onClose}>✕</button>
          </div>
          <div style={{ padding: '1rem' }}>
            <p>Total: <strong>${skill.isFree ? '0' : skill.price}</strong></p>
            <PayPalButtons
              createOrder={createOrder}
              onApprove={onApprove}
              onError={onError}
              style={{ layout: 'vertical' }}
            />
            <button className="btn btn-secondary" onClick={() => setStep('form')} style={{ marginTop: 12 }}>Back</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="card-header">
          <h3>Request Booking: {skill.title}</h3>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <form onSubmit={createBooking}>
          <div className="form-group">
            <label className="form-label">Date</label>
            <input type="date" className="form-control" required value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div className="form-group">
            <label className="form-label">Time</label>
            <input type="time" className="form-control" required value={time} onChange={e => setTime(e.target.value)} />
          </div>
          <div className="form-group">
            <label className="form-label">Message (optional)</label>
            <textarea className="form-control" rows={3} value={message} onChange={e => setMessage(e.target.value)} />
          </div>
          <div className="flex gap-md" style={{ marginTop: 16 }}>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? 'Creating...' : 'Proceed to Payment'}
            </button>
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BookingForm;