import React, { useState } from 'react';
import StarRating from '../common/StarRating';

const ReviewForm = ({ bookingId, onSubmit, onClose, loading }) => {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ bookingId, rating, comment });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="card-header">
          <h3>Leave a Review</h3>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Rating</label>
            <StarRating rating={rating} interactive onRatingChange={setRating} size={28} showValue />
          </div>
          <div className="form-group">
            <label className="form-label">Your Review</label>
            <textarea className="form-control" rows={4} required minLength={10} value={comment} onChange={e => setComment(e.target.value)} />
          </div>
          <button type="submit" className="btn btn-primary" disabled={loading || rating === 0}>{loading ? 'Submitting...' : 'Submit Review'}</button>
        </form>
      </div>
    </div>
  );
};

export default ReviewForm;