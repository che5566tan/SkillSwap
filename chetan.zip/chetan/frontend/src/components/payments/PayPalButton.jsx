import { PayPalButtons } from '@paypal/react-paypal-js';
import api from '../../services/api';
import toast from 'react-hot-toast';

const PayPalButton = ({ bookingId, amount, onSuccess }) => {
  const createOrder = async () => {
    try {
      const res = await api.post('/payments/create-order', { bookingId });
      return res.data.orderId;
    } catch (err) {
      toast.error(err.message);
      throw err;
    }
  };

  const onApprove = async (data) => {
    try {
      await api.post('/payments/capture-order', { orderId: data.orderID, bookingId });
      toast.success('Payment successful!');
      if (onSuccess) onSuccess();
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <PayPalButtons
      createOrder={createOrder}
      onApprove={onApprove}
      style={{ layout: 'vertical', color: 'gold', shape: 'pill' }}
    />
  );
};
export default PayPalButton;