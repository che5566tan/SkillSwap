import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  headers: { 'Content-Type': 'application/json' },
  timeout: 15000,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('skillswap_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Standardize error response so .message is always available
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      // Backend responded with a status code outside 2xx
      const data = error.response.data;
      let message = 'Something went wrong';
      if (data && typeof data === 'object') {
        // Handle different possible formats
        message = data.message || data.msg || (data.errors && data.errors[0]?.msg) || JSON.stringify(data);
      }
      error.displayMessage = message;
      
      // Auto logout on 401
      if (error.response.status === 401) {
        localStorage.removeItem('skillswap_token');
        if (window.location.pathname !== '/login') window.location.href = '/login';
      }
    } else if (error.request) {
      // Request was made but no response received
      error.displayMessage = 'Network error - unable to reach server';
    } else {
      error.displayMessage = error.message || 'Unknown error';
    }
    return Promise.reject(error);
  }
);

export default api;