import React, { createContext, useState, useEffect, useCallback } from 'react';
import api from '../services/api';

export const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('skillswap_token'));
  const [loading, setLoading] = useState(true);

  const loadUser = useCallback(async () => {
    const storedToken = localStorage.getItem('skillswap_token');
    if (!storedToken) { setLoading(false); return; }
    try {
      api.defaults.headers.common['Authorization'] = `Bearer ${storedToken}`;
      const res = await api.get('/auth/me');
      if (res.data.success) {
        setUser(res.data.user);
        setToken(storedToken);
      }
    } catch {
      localStorage.removeItem('skillswap_token');
      delete api.defaults.headers.common['Authorization'];
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadUser(); }, [loadUser]);

  const login = async (credentials) => {
    const res = await api.post('/auth/login', credentials);
    const { token: newToken, user: newUser } = res.data;
    localStorage.setItem('skillswap_token', newToken);
    api.defaults.headers.common['Authorization'] = `Bearer ${newToken}`;
    setToken(newToken);
    setUser(newUser);
    return res.data;
  };

  const register = async (userData) => {
    const res = await api.post('/auth/register', userData);
    const { token: newToken, user: newUser } = res.data;
    localStorage.setItem('skillswap_token', newToken);
    api.defaults.headers.common['Authorization'] = `Bearer ${newToken}`;
    setToken(newToken);
    setUser(newUser);
    return res.data;
  };
  const logout = () => {
    localStorage.removeItem('skillswap_token');
    delete api.defaults.headers.common['Authorization'];
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout, updateUser: setUser }}>
      {children}
    </AuthContext.Provider>
  );
};