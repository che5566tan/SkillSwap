import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './hooks/useAuth';
import Navbar from './components/common/Navbar';
import Footer from './components/common/Footer';
import Loader from './components/common/Loader';
import ProtectedRoute from './components/common/ProtectedRoute';

import Home from './pages/Home';
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import Dashboard from './pages/Dashboard';
import SearchSkills from './pages/SearchSkills';
import SkillDetailPage from './pages/SkillDetailPage';
import CreateSkill from './pages/CreateSkill';
import EditSkill from './pages/EditSkill';
import BookingRequests from './pages/BookingRequests';
import MyBookings from './pages/MyBookings';
import Profile from './pages/Profile';
import AdminDashboard from './pages/AdminDashboard';

const App = () => {
  const { loading, user } = useAuth();

  if (loading) return <Loader fullScreen text="Loading SkillSwap..." />;

  return (
    <>
      <Navbar />
      <main className="page-wrapper">
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={user ? <Navigate to="/dashboard" /> : <Login />} />
          <Route path="/register" element={user ? <Navigate to="/dashboard" /> : <Register />} />
          <Route path="/skills" element={<SearchSkills />} />
          <Route path="/skills/:id" element={<SkillDetailPage />} />

          {/* Protected Routes */}
          <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path="/skills/create" element={<ProtectedRoute><CreateSkill /></ProtectedRoute>} />
          <Route path="/skills/edit/:id" element={<ProtectedRoute><EditSkill /></ProtectedRoute>} />
          <Route path="/bookings/incoming" element={<ProtectedRoute><BookingRequests /></ProtectedRoute>} />
          <Route path="/bookings/my" element={<ProtectedRoute><MyBookings /></ProtectedRoute>} />
          <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
          <Route path="/admin" element={<ProtectedRoute requiredRole="admin"><AdminDashboard /></ProtectedRoute>} />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
    </>
  );
};

export default App;