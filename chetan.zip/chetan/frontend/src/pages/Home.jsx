import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import api from '../services/api';
import SkillCard from '../components/skills/SkillCard';

const Home = () => {
  const { user } = useAuth();
  const [popularSkills, setPopularSkills] = useState([]);

  useEffect(() => {
    api.get('/skills', { params: { sortBy: 'rating', limit: 6 } })
      .then(res => setPopularSkills(res.data.skills))
      .catch(console.error);
  }, []);

  return (
    <div>
      {/* Responsive CSS overrides (only for mobile) */}
      <style>{`
        @media (max-width: 768px) {
          .hero-section {
            padding: 80px 16px 40px !important;
          }
          .hero-title {
            font-size: 2.2rem !important;
          }
          .hero-subtitle {
            font-size: 1rem !important;
            max-width: 100% !important;
          }
          .hero-buttons {
            flex-direction: column;
            align-items: center;
          }
          .how-it-grid {
            grid-template-columns: 1fr !important;
          }
          .skills-grid {
            grid-template-columns: 1fr !important;
          }
          .cta-title {
            font-size: 1.5rem !important;
          }
        }
      `}</style>

      {/* ----- Hero Section ----- */}
      <section
        className="hero-section"
        style={{
          background: 'var(--gradient-hero)',
          textAlign: 'center',
          padding: '120px 20px 80px',
          borderBottom: '1px solid var(--border)',
        }}
      >
        <div className="container">
          <h1 className="gradient-text hero-title" style={{ fontSize: '3rem', marginBottom: 16 }}>
            Swap Skills, Grow Together
          </h1>
          <p className="hero-subtitle" style={{ fontSize: '1.2rem', maxWidth: 600, margin: '0 auto 32px', color: 'var(--text-secondary)' }}>
            Learn from passionate people, teach what you love. The peer‑to‑peer skill marketplace.
          </p>
          <div className="flex justify-center gap-md hero-buttons">
            {user ? (
              <Link to="/skills" className="btn btn-primary btn-xl">Browse Skills</Link>
            ) : (
              <Link to="/register" className="btn btn-primary btn-xl">Get Started Free</Link>
            )}
            <Link to="/skills" className="btn btn-outline btn-xl">Explore Listings</Link>
          </div>
        </div>
      </section>

      {/* ----- How It Works ----- */}
      <section className="section container">
        <h2 className="text-center gradient-text" style={{ marginBottom: 40 }}>How It Works</h2>
        <div className="grid grid-3 gap-lg how-it-grid" style={{ textAlign: 'center' }}>
          <div className="card">
            <div style={{ fontSize: '2rem', marginBottom: 12 }}>📋</div>
            <h3>1. List Your Skill</h3>
            <p>Create a listing describing what you can teach — free or paid.</p>
          </div>
          <div className="card">
            <div style={{ fontSize: '2rem', marginBottom: 12 }}>🔍</div>
            <h3>2. Find Sessions</h3>
            <p>Search by category, level, or keyword and request a session.</p>
          </div>
          <div className="card">
            <div style={{ fontSize: '2rem', marginBottom: 12 }}>⭐</div>
            <h3>3. Connect & Review</h3>
            <p>Attend the session, learn, and leave feedback for each other.</p>
          </div>
        </div>
      </section>

      {/* ----- Popular Skills ----- */}
      {popularSkills.length > 0 && (
        <section className="section container" style={{ paddingTop: 0 }}>
          <h2 className="gradient-text" style={{ marginBottom: 32 }}>Top Rated Skills</h2>
          <div className="skills-grid" style={{ display: 'grid', gap: 'var(--space-lg)' }}>
            {popularSkills.map(skill => (
              <SkillCard key={skill._id} skill={skill} />
            ))}
          </div>
          <div style={{ textAlign: 'center', marginTop: 24 }}>
            <Link to="/skills" className="btn btn-outline btn-lg">View All Skills</Link>
          </div>
        </section>
      )}
      {/* ----- Call to Action ----- */}
      {!user && (
        <section className="section" style={{ background: 'var(--bg-secondary)', borderTop: '1px solid var(--border)' }}>
          <div className="container" style={{ textAlign: 'center' }}>
            <h2 className="gradient-text cta-title" style={{ marginBottom: 16 }}>Ready to share your skills?</h2>
            <Link to="/register" className="btn btn-primary btn-xl">Create Free Account</Link>
          </div>
        </section>
      )}
    </div>
  );
};
export default Home;