import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import api from '../services/api';
import BookingCard from '../components/bookings/BookingCard';
import SkillCard from '../components/skills/SkillCard';
import toast from 'react-hot-toast';

const Dashboard = () => {
  const { user } = useAuth();
  const [mySkills, setMySkills] = useState([]);
  const [myBookings, setMyBookings] = useState([]);
  const [inComing, setInComing] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [skillsRes, myBkgRes, incRes] = await Promise.all([
          api.get('/skills/my-skills'),
          api.get('/bookings/my-bookings'),
          api.get('/bookings/incoming')
        ]);
        setMySkills(skillsRes.data.skills || []);
        setMyBookings(myBkgRes.data.bookings || []);
        setInComing(incRes.data.bookings || []);
      } catch (err) { toast.error('Failed to load dashboard'); }
      finally { setLoading(false); }
    };
    fetchData();
  }, []);

  if (loading) return <div className="container" style={{ paddingTop: 40 }}><div className="spinner" /></div>;

  const handleRespond = async (id, status) => {
    try {
      await api.put(`/bookings/${id}/respond`, { status });
      const res = await api.get('/bookings/incoming');
      setInComing(res.data.bookings);
      toast.success(`Booking ${status}`);
    } catch { toast.error('Action failed'); }
  };

  const handleComplete = async (id) => {
    try {
      await api.put(`/bookings/${id}/complete`);
      const res = await api.get('/bookings/my-bookings');
      setMyBookings(res.data.bookings);
      toast.success('Marked completed');
    } catch { toast.error('Failed'); }
  };

  const handleCancel = async (id) => {
    try {
      await api.put(`/bookings/${id}/cancel`);
      const res = await api.get('/bookings/my-bookings');
      setMyBookings(res.data.bookings);
      toast.success('Cancelled');
    } catch { toast.error('Cancel failed'); }
  };

  return (
    <div className="container dashboard-grid">
      <aside className="sidebar">
        <div className="flex items-center gap-md" style={{ marginBottom: 24 }}>
          <div className="avatar avatar-lg">{user.name?.charAt(0)}</div>
          <div>
            <h4 style={{ marginBottom: 0 }}>{user.name}</h4>
            <span className="badge badge-primary">{user.role}</span>
          </div>
        </div>
        <nav className="sidebar-nav">
          <Link to="/dashboard" className="sidebar-link active">Overview</Link>
          <Link to="/profile" className="sidebar-link">Edit Profile</Link>
          <Link to="/skills/create" className="sidebar-link">+ New Skill</Link>
          <Link to="/bookings/my" className="sidebar-link">My Bookings</Link>
          <Link to="/bookings/incoming" className="sidebar-link">Incoming Requests</Link>
          {user.role === 'admin' && (
            <Link to="/admin" className="sidebar-link" style={{ borderTop: '1px solid var(--border)', marginTop: 8, paddingTop: 12 }}>
              Admin Panel
            </Link>
          )}
        </nav>
      </aside>

      <main>
        <div className="stats-grid" style={{ gap: '24px' }}>
  {/* ----- Your Skills ----- */}
  <div
    className="stat-card"
    style={{
      background: 'linear-gradient(145deg, #1e293b 0%, #1f2a4a 100%)',
      border: '1px solid rgba(99,102,241,0.3)',
      borderRadius: '20px',
      padding: '24px',
      position: 'relative',
      overflow: 'hidden',
      transition: 'all 0.3s ease',
      cursor: 'default',
    }}
    onMouseEnter={(e) => {
      e.currentTarget.style.transform = 'translateY(-6px)';
      e.currentTarget.style.boxShadow = '0 20px 40px rgba(99,102,241,0.35), 0 0 0 2px rgba(99,102,241,0.2)';
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = 'none';
    }}
  >
    <div
      style={{
        width: '56px',
        height: '56px',
        borderRadius: '16px',
        background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: '18px',
        fontSize: '28px',
        boxShadow: '0 8px 20px rgba(99,102,241,0.3)',
      }}
    >
      📚
    </div>
    <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#e0e7ff', letterSpacing: '-0.5px' }}>
      {mySkills.length}
    </div>
    <div style={{ fontSize: '0.9rem', color: '#94a3b8', fontWeight: 500, marginTop: '6px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
      Your Skills
    </div>
    {/* subtle glow line */}
    <div
      style={{
        position: 'absolute',
        bottom: '0',
        left: '0',
        right: '0',
        height: '4px',
        background: 'linear-gradient(90deg, #6366f1, #06b6d4)',
        borderRadius: '0 0 20px 20px',
        opacity: 0.8,
      }}
    />
  </div>

  {/* ----- Your Bookings ----- */}
  <div
    className="stat-card"
    style={{
      background: 'linear-gradient(145deg, #1e293b 0%, #1a2e2a 100%)',
      border: '1px solid rgba(16,185,129,0.3)',
      borderRadius: '20px',
      padding: '24px',
      position: 'relative',
      overflow: 'hidden',
      transition: 'all 0.3s ease',
      cursor: 'default',
    }}
    onMouseEnter={(e) => {
      e.currentTarget.style.transform = 'translateY(-6px)';
      e.currentTarget.style.boxShadow = '0 20px 40px rgba(16,185,129,0.35), 0 0 0 2px rgba(16,185,129,0.2)';
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = 'none';
    }}
  >
    <div
      style={{
        width: '56px',
        height: '56px',
        borderRadius: '16px',
        background: 'linear-gradient(135deg, #10b981, #34d399)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: '18px',
        fontSize: '28px',
        boxShadow: '0 8px 20px rgba(16,185,129,0.3)',
      }}
    >
      📅
    </div>
    <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#d1fae5', letterSpacing: '-0.5px' }}>
      {myBookings.length}
    </div>
    <div style={{ fontSize: '0.9rem', color: '#94a3b8', fontWeight: 500, marginTop: '6px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
      Your Bookings
    </div>
    <div
      style={{
        position: 'absolute',
        bottom: '0',
        left: '0',
        right: '0',
        height: '4px',
        background: 'linear-gradient(90deg, #10b981, #06b6d4)',
        borderRadius: '0 0 20px 20px',
        opacity: 0.8,
      }}
    />
  </div>

  {/* ----- Incoming Requests ----- */}
  <div
    className="stat-card"
    style={{
      background: 'linear-gradient(145deg, #1e293b 0%, #2a241f 100%)',
      border: '1px solid rgba(245,158,11,0.3)',
      borderRadius: '20px',
      padding: '24px',
      position: 'relative',
      overflow: 'hidden',
      transition: 'all 0.3s ease',
      cursor: 'default',
    }}
    onMouseEnter={(e) => {
      e.currentTarget.style.transform = 'translateY(-6px)';
      e.currentTarget.style.boxShadow = '0 20px 40px rgba(245,158,11,0.35), 0 0 0 2px rgba(245,158,11,0.2)';
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = 'none';
    }}
  >
    <div
      style={{
        width: '56px',
        height: '56px',
        borderRadius: '16px',
        background: 'linear-gradient(135deg, #f59e0b, #fbbf24)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: '18px',
        fontSize: '28px',
        boxShadow: '0 8px 20px rgba(245,158,11,0.3)',
      }}
    >
      📨
    </div>
    <div style={{ fontSize: '2.2rem', fontWeight: 800, color: '#fef3c7', letterSpacing: '-0.5px' }}>
      {inComing.length}
    </div>
    <div style={{ fontSize: '0.9rem', color: '#94a3b8', fontWeight: 500, marginTop: '6px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
      Incoming Requests
    </div>
    <div
      style={{
        position: 'absolute',
        bottom: '0',
        left: '0',
        right: '0',
        height: '4px',
        background: 'linear-gradient(90deg, #f59e0b, #fbbf24)',
        borderRadius: '0 0 20px 20px',
        opacity: 0.8,
      }}
    />
  </div>
</div>

        <h3 style={{ marginTop: 32 }}>Your Skills</h3>
        <div className="skills-grid" style={{ marginBottom: 32 }}>
          {mySkills.length > 0 ? mySkills.map(skill => <SkillCard key={skill._id} skill={skill} />) : (
            <div className="card" style={{ textAlign: 'center', padding: 40 }}>
              <p>No skills yet.</p>
              <Link to="/skills/create" className="btn btn-primary btn-sm">Create One</Link>
            </div>
          )}
        </div>
        <h3>Incoming Booking Requests</h3>
        {inComing.length > 0 ? (
          inComing.map(b => (
            <BookingCard
              key={b._id}
              booking={b}
              userId={user._id}
              onRespond={handleRespond}
              onComplete={handleComplete}
            />
          ))
        ) : <p className="text-secondary">No incoming requests.</p>}

        <h3 style={{ marginTop: 32 }}>Recent Bookings</h3>
        {myBookings.slice(0, 5).map(b => (
          <BookingCard
            key={b._id}
            booking={b}
            userId={user._id}
            onCancel={handleCancel}
            onComplete={handleComplete}
          />
        ))}
        {myBookings.length === 0 && <p className="text-secondary">No bookings yet.</p>}
      </main>
    </div>
  );
};
export default Dashboard;