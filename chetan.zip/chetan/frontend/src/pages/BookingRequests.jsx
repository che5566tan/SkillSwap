import React, { useEffect, useState } from 'react';
import api from '../services/api';
import BookingCard from '../components/bookings/BookingCard';
import toast from 'react-hot-toast';
import { useAuth } from '../hooks/useAuth';

const BookingRequests = () => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/bookings/incoming')
      .then(res => setBookings(res.data.bookings))
      .catch(() => toast.error('Failed to load'))
      .finally(() => setLoading(false));
  }, []);

  const handleRespond = async (id, status) => {
    try {
      await api.put(`/bookings/${id}/respond`, { status });
      const res = await api.get('/bookings/incoming');
      setBookings(res.data.bookings);
      toast.success(`Booking ${status}`);
    } catch { toast.error('Failed'); }
  };

  const handleComplete = async (id) => {
    try {
      await api.put(`/bookings/${id}/complete`);
      const res = await api.get('/bookings/incoming');
      setBookings(res.data.bookings);
      toast.success('Completed');
    } catch { toast.error('Failed'); }
  };

  return (
    <div className="container" style={{ maxWidth: 800 }}>
      <h2 className="gradient-text" style={{ marginBottom: 24 }}>Incoming Booking Requests</h2>
      {loading ? <div className="spinner" style={{ margin: '40px auto' }} /> :
        bookings.length === 0 ? <p className="text-secondary">No requests yet.</p> :
        bookings.map(b => (
          <BookingCard
            key={b._id}
            booking={b}
            userId={user._id}
            onRespond={handleRespond}
            onComplete={handleComplete}
            onReview={() => {}}
          />
        ))
      }
    </div>
  );
};
export default BookingRequests;