import React, { useEffect, useState } from 'react';
import api from '../services/api';
import SkillCard from '../components/skills/SkillCard';
import SkillSearchInput from '../components/common/SkillSearchInput';
import { useSearchParams } from 'react-router-dom';

const SearchSkills = () => {
  const [skills, setSkills] = useState([]);
  const [pagination, setPagination] = useState({});
  const [loading, setLoading] = useState(true);
  const [searchParams, setSearchParams] = useSearchParams();

  const fetchSkills = async (params = {}) => {
    setLoading(true);
    try {
      const res = await api.get('/skills', { params });
      setSkills(res.data.skills);
      setPagination(res.data.pagination);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    const params = Object.fromEntries(searchParams.entries());
    fetchSkills(params);
  }, [searchParams]);

  const handleSearch = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    const params = {};
    formData.forEach((value, key) => { if (value) params[key] = value; });
    setSearchParams(params);
  };

  return (
    <>
      {/* Responsive overrides for mobile */}
      <style>{`
        @media (max-width: 768px) {
          .search-form .grid {
            grid-template-columns: 1fr !important;
          }
          .search-form .grid > div[style*="span 2"] {
            grid-column: span 1 !important;
          }
          .pagination-container {
            flex-wrap: wrap;
            justify-content: center;
          }
        }
      `}</style>

      <div className="container">
        <h1 className="gradient-text" style={{ marginBottom: 24 }}>Discover Skills</h1>

        <form onSubmit={handleSearch} className="card search-form" style={{ marginBottom: 32 }}>
          <div className="grid grid-4 gap-md">
            {/* Autocomplete input replaces simple search */}
            <div style={{ gridColumn: 'span 2' }}>
              <SkillSearchInput />
            </div>
            <select name="category" className="form-control" defaultValue={searchParams.get('category') || ''}>
              <option value="">All Categories</option>
              {['Technology','Music','Language','Cooking','Design','Business','Fitness','Arts & Crafts','Academic','Other'].map(c => <option key={c}>{c}</option>)}
            </select>
            <select name="level" className="form-control" defaultValue={searchParams.get('level') || ''}>
              <option value="">All Levels</option>
              <option>Beginner</option><option>Intermediate</option><option>Advanced</option><option>All Levels</option>
            </select>
          </div>
          <button type="submit" className="btn btn-primary" style={{ marginTop: 16 }}>Apply Filters</button>
        </form>

        {loading ? <div className="spinner" style={{ margin: '40px auto' }} /> : (
          <>
            <div className="skills-grid">
              {skills.map(skill => <SkillCard key={skill._id} skill={skill} />)}
            </div>
            {pagination.pages > 1 && (
              <div className="flex justify-center gap-sm pagination-container" style={{ marginTop: 32 }}>
                {Array.from({ length: pagination.pages }, (_, i) => (
                  <button
                    key={i+1}
                    className={`btn btn-sm ${pagination.page === i+1 ? 'btn-primary' : 'btn-ghost'}`}
                    onClick={() => {
                      const newParams = new URLSearchParams(searchParams);
                      newParams.set('page', i+1);
                      setSearchParams(newParams);
                    }}
                  >{i+1}</button>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
};

export default SearchSkills;