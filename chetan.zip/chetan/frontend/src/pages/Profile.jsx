import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import api from '../services/api';
import toast from 'react-hot-toast';

const Profile = () => {
  const { user, updateUser } = useAuth();
  const [form, setForm] = useState({ name: '', bio: '', location: '', role: '' });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) setForm({ name: user.name, bio: user.bio || '', location: user.location || '', role: user.role });
  }, [user]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.put('/users/profile/update', form);
      updateUser(res.data.user);
      toast.success('Profile updated');
    } catch (err) { toast.error(err.response?.data?.message || 'Error'); }
    finally { setLoading(false); }
  };

  return (
    <div className="container-sm" style={{ maxWidth: 500 }}>
      <h2 className="gradient-text" style={{ marginBottom: 24 }}>Profile Settings</h2>
      <div className="card">
        <div className="avatar avatar-xl" style={{ marginBottom: 16 }}>{user.name.charAt(0)}</div>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Name</label>
            <input type="text" name="name" className="form-control" value={form.name} onChange={handleChange} required />
          </div>
          <div className="form-group">
            <label className="form-label">Bio</label>
            <textarea name="bio" className="form-control" value={form.bio} onChange={handleChange} />
          </div>
          <div className="form-group">
            <label className="form-label">Location</label>
            <input type="text" name="location" className="form-control" value={form.location} onChange={handleChange} />
          </div>
          <div className="form-group">
            <label className="form-label">Role</label>
            <select name="role" className="form-control" value={form.role} onChange={handleChange}>
              <option value="learner">Learner</option>
              <option value="provider">Provider</option>
            </select>
          </div>
          <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%' }} disabled={loading}>
            {loading ? 'Updating...' : 'Update Profile'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Profile;