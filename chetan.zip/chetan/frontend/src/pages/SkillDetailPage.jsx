import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../services/api';
import StarRating from '../components/common/StarRating';
import BookingForm from '../components/bookings/BookingForm';
import toast from 'react-hot-toast';
import { useAuth } from '../hooks/useAuth';

const SkillDetailPage = () => {
  const { id } = useParams();
  const [skill, setSkill] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [showBooking, setShowBooking] = useState(false);
  const [bookingLoading, setBookingLoading] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    const fetchSkill = async () => {
      try {
        const res = await api.get(`/skills/${id}`);
        setSkill(res.data.skill);
        setReviews(res.data.reviews);
      } catch (err) { toast.error('Failed to load skill'); }
    };
    fetchSkill();
  }, [id]);

  const handleBookingSubmit = async (data) => {
    setBookingLoading(true);
    try {
      await api.post('/bookings', data);
      toast.success('Booking request sent!');
      setShowBooking(false);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Booking failed');
    } finally { setBookingLoading(false); }
  };

  if (!skill) return <div className="container" style={{ paddingTop: 40 }}><div className="spinner" /></div>;

  return (
    <>
      {/* Responsive overrides for mobile */}
      <style>{`
        @media (max-width: 768px) {
          .skill-detail-header {
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 16px !important;
          }
          .skill-detail-header .skill-price-box {
            text-align: left !important;
            margin-top: 8px;
          }
          .skill-detail-title {
            font-size: 1.6rem !important;
          }
          .skill-provider-row {
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 12px !important;
          }
          .skill-provider-row .avatar-lg {
            width: 48px !important;
            height: 48px !important;
            font-size: 1rem !important;
          }
          .availability-item {
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 4px !important;
          }
          .review-card {
            flex-direction: column !important;
            gap: 8px !important;
          }
          .review-card .flex.justify-between {
            flex-direction: column !important;
            align-items: flex-start !important;
            gap: 6px;
          }
          .btn-full-width-mobile {
            width: 100% !important;
          }
        }
      `}</style>

      <div className="container" style={{ maxWidth: 800 }}>
        <div className="card animate-fade-in" style={{ marginBottom: 32 }}>
          {/* Header: category + level + title vs price */}
          <div className="flex justify-between items-start skill-detail-header">
            <div style={{ flex: 1 }}>
              <span className="badge badge-primary">{skill.category}</span>
              <span className="badge badge-secondary" style={{ marginLeft: 8 }}>{skill.level}</span>
              <h1 className="skill-detail-title" style={{ marginTop: 12 }}>{skill.title}</h1>
            </div>
            <div className="skill-price-box" style={{ textAlign: 'right' }}>
              <span className="gradient-text" style={{ fontSize: '2rem', fontWeight: 700 }}>
                {skill.isFree ? 'Free' : `$${skill.price}`}
              </span>
              <p className="text-secondary">{skill.sessionDuration} mins</p>
            </div>
          </div>

          <p style={{ whiteSpace: 'pre-wrap', margin: '16px 0' }}>{skill.description}</p>
          <div className="tags-container" style={{ marginBottom: 16 }}>
            {skill.tags?.map(tag => <span key={tag} className="tag">{tag}</span>)}
          </div>

          {/* Provider info */}
          <div className="flex items-center gap-md skill-provider-row">
            <div className="avatar avatar-lg">{skill.provider?.name?.charAt(0)}</div>
            <div>
              <strong>{skill.provider?.name}</strong>
              <StarRating rating={skill.rating?.average} size={16} showValue count={skill.rating?.count} />
              <p className="text-secondary">{skill.provider?.bio?.slice(0, 100)}</p>
            </div>
          </div>

          {/* Availability */}
          <div style={{ marginTop: 24 }}>
            <h4>Availability</h4>
            {skill.availability?.length ? skill.availability.map(s => (
              <div key={s._id} className="flex justify-between availability-item" style={{ padding: '4px 0' }}>
                <strong>{s.day}</strong>
                <span>{s.startTime} - {s.endTime}</span>
              </div>
            )) : <p className="text-secondary">Flexible schedule</p>}
          </div>

          {user && user._id !== skill.provider._id && (
            <button
              onClick={() => setShowBooking(true)}
              className="btn btn-primary btn-lg btn-full-width-mobile"
              style={{ marginTop: 24, width: '100%' }}
            >
              Request a Session
            </button>
          )}
        </div>

        {/* Reviews */}
        <h3>Reviews ({reviews.length})</h3>
        {reviews.map(r => (
          <div key={r._id} className="card review-card" style={{ marginBottom: 12 }}>
            <div className="flex justify-between">
              <div className="flex items-center gap-sm">
                <div className="avatar avatar-sm">{r.reviewer?.name?.charAt(0)}</div>
                <strong>{r.reviewer?.name}</strong>
              </div>
              <StarRating rating={r.rating} size={14} />
            </div>
            <p className="text-secondary" style={{ marginTop: 8 }}>{r.comment}</p>
          </div>
        ))}
        {showBooking && (
          <BookingForm
            skill={skill}
            onClose={() => setShowBooking(false)}
            onSuccess={() => {
              setShowBooking(false);
              toast.success('Booking & payment successful!');
            }}
          />
        )}
      </div>
    </>
  );
};
export default SkillDetailPage;