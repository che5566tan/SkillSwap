import React, { useEffect, useState } from 'react';
import api from '../services/api';
import BookingCard from '../components/bookings/BookingCard';
import ReviewForm from '../components/reviews/ReviewForm';
import PayPalButton from '../components/payments/PayPalButton';  // NEW
import toast from 'react-hot-toast';
import { useAuth } from '../hooks/useAuth';

const MyBookings = () => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [reviewBooking, setReviewBooking] = useState(null);

  const fetchBookings = () => {
    api.get('/bookings/my-bookings')
      .then(res => setBookings(res.data.bookings))
      .catch(() => toast.error('Failed to load bookings'))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleCancel = async (id) => {
    try {
      await api.put(`/bookings/${id}/cancel`);
      fetchBookings();
      toast.success('Cancelled');
    } catch { toast.error('Failed'); }
  };

  const handleComplete = async (id) => {
    try {
      await api.put(`/bookings/${id}/complete`);
      fetchBookings();
      toast.success('Completed');
    } catch { toast.error('Failed'); }
  };

  const handleReviewSubmit = async (data) => {
    try {
      await api.post('/reviews', data);
      toast.success('Review submitted');
      setReviewBooking(null);
      fetchBookings();
    } catch (err) { toast.error(err.response?.data?.message || 'Error'); }
  };

  // NEW: refresh after payment success
  const handlePaymentSuccess = () => {
    fetchBookings();
    toast.success('Payment completed! Your booking is confirmed.');
  };

  return (
    <div className="container" style={{ maxWidth: 800 }}>
      <h2 className="gradient-text" style={{ marginBottom: 24 }}>My Bookings</h2>
      {loading ? <div className="spinner" style={{ margin: '40px auto' }} /> :
        bookings.length === 0 ? <p className="text-secondary">No bookings found.</p> :
        bookings.map(b => (
          <div key={b._id} style={{ marginBottom: 20 }}>
            <BookingCard
              booking={b}
              userId={user._id}
              onCancel={handleCancel}
              onComplete={handleComplete}
              onReview={(bookingId) => setReviewBooking(bookingId)}
            />
            {/* NEW: Show PayPal button if booking accepted and payment pending */}
            {b.status === 'accepted' && b.paymentStatus === 'pending' && (
              <div style={{ marginTop: 12, padding: '12px 16px', background: '#f5f5f5', borderRadius: 8 }}>
                <p style={{ marginBottom: 12, fontWeight: 'bold' }}>Complete your payment to confirm the booking:</p>
                <PayPalButton 
                  bookingId={b._id} 
                  amount={b.totalPrice} 
                  onSuccess={handlePaymentSuccess} 
                />
              </div>
            )}
          </div>
        ))
      }
      {reviewBooking && (
        <ReviewForm
          bookingId={reviewBooking}
          onSubmit={handleReviewSubmit}
          onClose={() => setReviewBooking(null)}
        />
      )}
    </div>
  );
};

export default MyBookings;