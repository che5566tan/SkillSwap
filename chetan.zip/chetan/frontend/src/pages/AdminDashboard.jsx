import React, { useEffect, useState } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { useAuth } from '../hooks/useAuth';

// Custom styles for admin tables
const tableStyle = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: '0.9rem',
};

const thStyle = {
  textAlign: 'left',
  padding: '12px 16px',
  background: 'var(--bg-secondary)',
  borderBottom: '2px solid var(--border)',
  fontWeight: 600,
  color: 'var(--text-secondary)',
  textTransform: 'uppercase',
  fontSize: '0.75rem',
  letterSpacing: '0.05em',
};

const tdStyle = {
  padding: '14px 16px',
  borderBottom: '1px solid var(--border)',
  color: 'var(--text-primary)',
  verticalAlign: 'middle',
};

const trHoverStyle = {
  transition: 'background 0.15s',
};

const AdminDashboard = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('stats');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [skills, setSkills] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editItem, setEditItem] = useState(null);

  useEffect(() => {
    const fetchAll = async () => {
      setLoading(true);
      try {
        const [statsRes, usersRes, skillsRes, bookingsRes, reviewsRes] = await Promise.all([
          api.get('/admin/stats'),
          api.get('/admin/users', { params: { limit: 100 } }),
          api.get('/admin/skills', { params: { limit: 100 } }),
          api.get('/admin/bookings'),
          api.get('/admin/reviews'),
        ]);
        setStats(statsRes.data.stats);
        setUsers(usersRes.data.users);
        setSkills(skillsRes.data.skills);
        setBookings(bookingsRes.data.bookings);
        setReviews(reviewsRes.data.reviews);
      } catch (err) {
        toast.error('Failed to load admin data');
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  const handleBan = async (userId) => {
    try {
      const res = await api.put(`/admin/users/${userId}/ban`);
      setUsers(users.map(u => u._id === userId ? res.data.user : u));
      toast.success(res.data.message);
    } catch { toast.error('Ban failed'); }
  };

  const handleRoleChange = async (userId, newRole) => {
    try {
      const res = await api.put(`/admin/users/${userId}/role`, { role: newRole });
      setUsers(users.map(u => u._id === userId ? res.data.user : u));
      toast.success('Role updated');
    } catch { toast.error('Failed'); }
  };

  const handleUpdateUser = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const data = Object.fromEntries(form.entries());
    data.isBanned = data.isBanned === 'on';
    try {
      const res = await api.put(`/admin/users/${editItem.data._id}`, data);
      setUsers(users.map(u => u._id === editItem.data._id ? res.data.user : u));
      toast.success('User updated');
      setEditItem(null);
    } catch { toast.error('Update failed'); }
  };

  const handleDeleteSkill = async (skillId) => {
    if (!window.confirm('Delete this skill?')) return;
    try {
      await api.delete(`/admin/skills/${skillId}`);
      setSkills(skills.filter(s => s._id !== skillId));
      toast.success('Skill deleted');
    } catch { toast.error('Failed'); }
  };

  const handleUpdateBooking = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const data = Object.fromEntries(form.entries());
    try {
      const res = await api.put(`/admin/bookings/${editItem.data._id}`, data);
      setBookings(bookings.map(b => b._id === editItem.data._id ? res.data.booking : b));
      toast.success('Booking updated');
      setEditItem(null);
    } catch { toast.error('Update failed'); }
  };

  const handleDeleteReview = async (reviewId) => {
    if (!window.confirm('Delete this review? This will recalculate ratings.')) return;
    try {
      await api.delete(`/admin/reviews/${reviewId}`);
      setReviews(reviews.filter(r => r._id !== reviewId));
      toast.success('Review deleted');
    } catch { toast.error('Failed'); }
  };

  if (loading) return (
    <div className="container" style={{ paddingTop: 40, textAlign: 'center' }}>
      <div className="spinner" />
    </div>
  );

  const renderTab = () => {
    switch (activeTab) {
      case 'users':
        return (
          <div>
            <h2 className="gradient-text" style={{ marginBottom: 24 }}>Manage Users</h2>
            <div style={{ overflowX: 'auto', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)' }}>
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <th style={thStyle}>Name</th>
                    <th style={thStyle}>Email</th>
                    <th style={thStyle}>Role</th>
                    <th style={thStyle}>Banned</th>
                    <th style={thStyle}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u, i) => (
                    <tr
                      key={u._id}
                      style={{ ...trHoverStyle, background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.02)' }}
                      onMouseEnter={(e) => e.currentTarget.style.background = 'var(--bg-tertiary)'}
                      onMouseLeave={(e) => e.currentTarget.style.background = i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.02)'}
                    >
                      <td style={tdStyle}>{u.name}</td>
                      <td style={tdStyle}>{u.email}</td>
                      <td style={tdStyle}>
                        <select
                          value={u.role}
                          className="form-control" style={{ width: 110, padding: '6px 12px' }}
                          onChange={(e) => handleRoleChange(u._id, e.target.value)}
                        >
                          <option value="learner">Learner</option>
                          <option value="provider">Provider</option>
                          <option value="admin">Admin</option>
                        </select>
                      </td>
                      <td style={tdStyle}>{u.isBanned ? <span className="badge badge-error">Yes</span> : <span className="badge badge-success">No</span>}</td>
                      <td style={tdStyle}>
                        <div className="flex gap-sm">
                          <button onClick={() => handleBan(u._id)} className="btn btn-sm btn-ghost">{u.isBanned ? 'Unban' : 'Ban'}</button>
                          <button onClick={() => setEditItem({ type: 'user', data: u })} className="btn btn-sm btn-outline">Edit</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      case 'skills':
        return (
          <div>
            <h2 className="gradient-text" style={{ marginBottom: 24 }}>Manage Skills</h2>
            <div style={{ overflowX: 'auto', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)' }}>
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <th style={thStyle}>Title</th>
                    <th style={thStyle}>Provider</th>
                    <th style={thStyle}>Category</th>
                    <th style={thStyle}>Status</th>
                    <th style={thStyle}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {skills.map((s, i) => (
                    <tr
                      key={s._id}
                      style={{ ...trHoverStyle, background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.02)' }}
                      onMouseEnter={(e) => e.currentTarget.style.background = 'var(--bg-tertiary)'}
                      onMouseLeave={(e) => e.currentTarget.style.background = i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.02)'}
                    >
                      <td style={tdStyle}>{s.title}</td>
                      <td style={tdStyle}>{s.provider?.name}</td>
                      <td style={tdStyle}><span className="badge badge-secondary">{s.category}</span></td>
                      <td style={tdStyle}>{s.isActive ? <span className="badge badge-success">Active</span> : <span className="badge badge-warning">Inactive</span>}</td>
                      <td style={tdStyle}>
                        <div className="flex gap-sm">
                          <button onClick={() => setEditItem({ type: 'skill', data: s })} className="btn btn-sm btn-outline">Edit</button>
                          <button onClick={() => handleDeleteSkill(s._id)} className="btn btn-sm btn-danger">Delete</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      case 'bookings':
        return (
          <div>
            <h2 className="gradient-text" style={{ marginBottom: 24 }}>Manage Bookings</h2>
            <div style={{ overflowX: 'auto', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)' }}>
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <th style={thStyle}>Skill</th>
                    <th style={thStyle}>Learner</th>
                    <th style={thStyle}>Provider</th>
                    <th style={thStyle}>Status</th>
                    <th style={thStyle}>Date</th>
                    <th style={thStyle}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {bookings.map((b, i) => (
                    <tr
                      key={b._id}
                      style={{ ...trHoverStyle, background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.02)' }}
                      onMouseEnter={(e) => e.currentTarget.style.background = 'var(--bg-tertiary)'}
                      onMouseLeave={(e) => e.currentTarget.style.background = i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.02)'}
                    >
                      <td style={tdStyle}>{b.skill?.title}</td>
                      <td style={tdStyle}>{b.learner?.name}</td>
                      <td style={tdStyle}>{b.provider?.name}</td>
                      <td style={tdStyle}>
                        <span className={`badge badge-${
                          b.status === 'completed' ? 'success' :
                          b.status === 'pending' ? 'warning' :
                          b.status === 'accepted' ? 'primary' : 'neutral'
                        }`}>{b.status}</span>
                      </td>
                      <td style={tdStyle}>{new Date(b.requestedDate).toLocaleDateString()}</td>
                      <td style={tdStyle}>
                        <button onClick={() => setEditItem({ type: 'booking', data: b })} className="btn btn-sm btn-outline">Edit</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      case 'reviews':
        return (
          <div>
            <h2 className="gradient-text" style={{ marginBottom: 24 }}>Manage Reviews</h2>
            <div style={{ overflowX: 'auto', borderRadius: 'var(--radius-lg)', border: '1px solid var(--border)' }}>
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <th style={thStyle}>Skill</th>
                    <th style={thStyle}>Reviewer</th>
                    <th style={thStyle}>Reviewee</th>
                    <th style={thStyle}>Rating</th>
                    <th style={thStyle}>Comment</th>
                    <th style={thStyle}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {reviews.map((r, i) => (
                    <tr
                      key={r._id}
                      style={{ ...trHoverStyle, background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.02)' }}
                      onMouseEnter={(e) => e.currentTarget.style.background = 'var(--bg-tertiary)'}
                      onMouseLeave={(e) => e.currentTarget.style.background = i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.02)'}
                    >
                      <td style={tdStyle}>{r.skill?.title}</td>
                      <td style={tdStyle}>{r.reviewer?.name}</td>
                      <td style={tdStyle}>{r.reviewee?.name}</td>
                      <td style={tdStyle}>⭐ {r.rating}</td>
                      <td style={{ ...tdStyle, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.comment}</td>
                      <td style={tdStyle}>
                        <button onClick={() => handleDeleteReview(r._id)} className="btn btn-sm btn-danger">Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      default:
        return (
          <>
            <h2 className="gradient-text" style={{ marginBottom: 24 }}>Platform Statistics</h2>
            <div className="stats-grid">
              <div className="stat-card"><div className="stat-number">{stats.totalUsers}</div><div className="stat-label">Users</div></div>
              <div className="stat-card"><div className="stat-number">{stats.totalSkills}</div><div className="stat-label">Skills</div></div>
              <div className="stat-card"><div className="stat-number">{stats.totalBookings}</div><div className="stat-label">Bookings</div></div>
              <div className="stat-card"><div className="stat-number">{stats.totalReviews}</div><div className="stat-label">Reviews</div></div>
            </div>
            <div className="grid grid-2 gap-lg" style={{ marginTop: 32 }}>
              <div className="card">
                <h4>Users by Role</h4>
                {stats.userRoleStats.map(r => (
                  <div key={r._id} className="flex justify-between" style={{ padding: '8px 0' }}>
                    <span>{r._id}</span><strong>{r.count}</strong>
                  </div>
                ))}
              </div>
              <div className="card">
                <h4>Bookings by Status</h4>
                {stats.bookingStats.map(b => (
                  <div key={b._id} className="flex justify-between" style={{ padding: '8px 0' }}>
                    <span>{b._id}</span><strong>{b.count}</strong>
                  </div>
                ))}
              </div>
            </div>
          </>
        );
    }
  };

  return (
    <div className="container dashboard-grid">
      <aside className="sidebar">
        <div style={{ marginBottom: 24 }}>
          <div className="avatar avatar-lg" style={{ margin: '0 auto' }}>{user.name?.charAt(0)}</div>
          <h3 style={{ textAlign: 'center', marginTop: 8 }}>{user.name}</h3>
          <p style={{ textAlign: 'center', color: 'var(--text-secondary)', fontSize: '0.9rem' }}>Administrator</p>
        </div>
        <nav className="sidebar-nav">
          <button className={`sidebar-link ${activeTab === 'stats' ? 'active' : ''}`} onClick={() => setActiveTab('stats')}>📊 Dashboard</button>
          <button className={`sidebar-link ${activeTab === 'users' ? 'active' : ''}`} onClick={() => setActiveTab('users')}>👥 Users</button>
          <button className={`sidebar-link ${activeTab === 'skills' ? 'active' : ''}`} onClick={() => setActiveTab('skills')}>📚 Skills</button>
          <button className={`sidebar-link ${activeTab === 'bookings' ? 'active' : ''}`} onClick={() => setActiveTab('bookings')}>📅 Bookings</button>
          <button className={`sidebar-link ${activeTab === 'reviews' ? 'active' : ''}`} onClick={() => setActiveTab('reviews')}>⭐ Reviews</button>
        </nav>
      </aside>
      <main>
        {renderTab()}

        {/* Edit Modals */}
        {editItem && (
          <div className="modal-overlay" onClick={() => setEditItem(null)}>
            <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: 600, maxHeight: '90vh', overflowY: 'auto' }}>
              <div className="card-header">
                <h3>Edit {editItem.type}</h3>
                <button className="modal-close" onClick={() => setEditItem(null)}>✕</button>
              </div>

              {editItem.type === 'user' && (
                <form onSubmit={handleUpdateUser}>
                  <div className="form-group"><label className="form-label">Name</label><input className="form-control" name="name" defaultValue={editItem.data.name} /></div>
                  <div className="form-group"><label className="form-label">Email</label><input className="form-control" name="email" defaultValue={editItem.data.email} /></div>
                  <div className="form-group"><label className="form-label">Bio</label><textarea className="form-control" name="bio" defaultValue={editItem.data.bio || ''} /></div>
                  <div className="form-group"><label className="form-label">Location</label><input className="form-control" name="location" defaultValue={editItem.data.location || ''} /></div>
                  <div className="form-group" style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <input type="checkbox" id="isBanned" name="isBanned" defaultChecked={editItem.data.isBanned} />
                    <label htmlFor="isBanned" style={{ fontSize: '0.9rem' }}>Banned</label>
                  </div>
                  <button type="submit" className="btn btn-primary btn-sm">Save User</button>
                </form>
              )}

              {editItem.type === 'booking' && (
                <form onSubmit={handleUpdateBooking}>
                  <div className="form-group"><label className="form-label">Status</label>
                    <select name="status" className="form-control" defaultValue={editItem.data.status}>
                      <option value="pending">Pending</option><option value="accepted">Accepted</option><option value="rejected">Rejected</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option>
                    </select>
                  </div>
                  <div className="form-group"><label className="form-label">Session Link</label><input className="form-control" name="sessionLink" defaultValue={editItem.data.sessionLink || ''} /></div>
                  <div className="form-group"><label className="form-label">Notes</label><textarea className="form-control" name="notes" defaultValue={editItem.data.notes || ''} /></div>
                  <div className="form-group"><label className="form-label">Provider Response</label><input className="form-control" name="providerResponse" defaultValue={editItem.data.providerResponse || ''} /></div>
                  <button type="submit" className="btn btn-primary btn-sm">Update Booking</button>
                </form>
              )}

              {editItem.type === 'skill' && (
                <form onSubmit={async (e) => {
                  e.preventDefault();
                  const form = new FormData(e.target);
                  const data = Object.fromEntries(form.entries());
                  try {
                    const res = await api.put(`/admin/skills/${editItem.data._id}`, data);
                    setSkills(skills.map(s => s._id === editItem.data._id ? res.data.skill : s));
                    toast.success('Skill updated');
                    setEditItem(null);
                  } catch { toast.error('Update failed'); }
                }}>
                  <div className="form-group"><label className="form-label">Title</label><input className="form-control" name="title" defaultValue={editItem.data.title} /></div>
                  <div className="form-group"><label className="form-label">Category</label><input className="form-control" name="category" defaultValue={editItem.data.category} /></div>
                  <div className="form-group"><label className="form-label">Level</label><input className="form-control" name="level" defaultValue={editItem.data.level} /></div>
                  <div className="form-group"><label className="form-label">Price</label><input className="form-control" type="number" name="price" defaultValue={editItem.data.price} /></div>
                  <div className="form-group"><label className="form-label">Active</label>
                    <select name="isActive" className="form-control" defaultValue={editItem.data.isActive.toString()}>
                      <option value="true">Yes</option><option value="false">No</option>
                    </select>
                  </div>
                  <button type="submit" className="btn btn-primary btn-sm">Save Skill</button>
                </form>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;