import React, { useState } from 'react';
import SkillForm from '../components/skills/SkillForm';
import api from '../services/api';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

const CreateSkill = () => {
  const [form, setForm] = useState({
    title: '', description: '', category: '', level: '', price: 0, isFree: false, sessionDuration: 60,
    deliveryMethod: 'Online', tags: [], availability: []
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
  e.preventDefault();
  setLoading(true);
  try {
    await api.post('/skills', form);
    toast.success('Skill created!');
    navigate('/dashboard');
  } catch (err) {
    // Use the standardized message from interceptor
    toast.error(err.displayMessage || 'Failed to create skill');
    console.error('Create skill error:', err.response?.data);
  } finally {
    setLoading(false);
  }
};

  return (
    <div className="container">
      <SkillForm formData={form} setFormData={setForm} onSubmit={handleSubmit} loading={loading} />
    </div>
  );
};

export default CreateSkill;