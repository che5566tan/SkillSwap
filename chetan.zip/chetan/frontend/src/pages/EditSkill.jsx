import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import SkillForm from '../components/skills/SkillForm';
import api from '../services/api';
import toast from 'react-hot-toast';

const EditSkill = () => {
  const { id } = useParams();
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchSkill = async () => {
      try {
        const res = await api.get(`/skills/${id}`);
        const skill = res.data.skill;
        if (skill.provider._id !== JSON.parse(atob(localStorage.skillswap_token.split('.')[1])).id) {
          toast.error('Unauthorized'); navigate('/');
        }
        setForm(skill);
      } catch { toast.error('Skill not found'); navigate('/'); }
    };
    fetchSkill();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.put(`/skills/${id}`, form);
      toast.success('Skill updated!');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Error');
    } finally { setLoading(false); }
  };

  if (!form) return <div className="container"><div className="spinner" /></div>;
  return (
    <div className="container">
      <SkillForm formData={form} setFormData={setForm} onSubmit={handleSubmit} loading={loading} isEdit />
    </div>
  );
};

export default EditSkill;
